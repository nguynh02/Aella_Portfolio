*******************************************************
* ECON 352 Milestone 2
* Step 1: Import CPS, clean teen sample, merge MW data
*******************************************************

clear all
set more off
capture log close

* 0. Set project folder
cd "H:\Private\ECON 352\ECON352_Milestone2"

* Start a log so every check is saved
log using "01_build_merged_data.log", text replace

*******************************************************
* 1. IMPORT IPUMS-CPS RAW DATA
*******************************************************

* IPUMS generated this command file. It reads cps_00001.dat
* and applies the correct variable labels and weights.
do "cps_00001.txt"

* Basic checks
count
summarize year age
tab age
tab sex
tab empstat

* Keep civilian teenagers only
drop if empstat == 1

* Main outcome: employed = 1 if at work or has a job
gen byte employed = inlist(empstat, 10, 12)
label define employed_lbl 0 "Not employed" 1 "Employed"
label values employed employed_lbl
label var employed "Employed (1=yes, 0=no)"

* Check outcome
tab employed
mean employed [pw=wtfinl]

* Check missing values in core variables
count if missing(year, month, statefip, age, sex, empstat, wtfinl)

* Save clean CPS file
save "cps_teens_2010_2019_clean.dta", replace

*******************************************************
* 2. PREPARE MONTHLY STATE MINIMUM-WAGE DATA
*******************************************************

use "mw_state_monthly.dta", clear

* monthly_date is a Stata monthly date
gen year  = year(dofm(monthly_date))
gen month = month(dofm(monthly_date))

keep if inrange(year, 2010, 2019)

rename statefips statefip

* Confirm one row per state-year-month
isid statefip year month

keep statefip year month statename stateabb monthly_date ///
     min_fed_mw mean_fed_mw max_fed_mw ///
     min_mw mean_mw max_mw

save "mw_2010_2019_monthly_clean.dta", replace

*******************************************************
* 3. MERGE CPS PEOPLE WITH STATE MINIMUM WAGE
*******************************************************

use "cps_teens_2010_2019_clean.dta", clear

merge m:1 statefip year month using "mw_2010_2019_monthly_clean.dta"

* IMPORTANT: inspect this table before moving on
tab _merge

* For now, keep matched observations only
keep if _merge == 3
drop _merge

label var mean_mw "Average state minimum wage in month ($)"

* Final checks
count
summarize year month age employed mean_mw wtfinl
tab age
tab sex

save "teen_cps_mw_merged_2010_2019.dta", replace

log close

*******************************************************
* STOP HERE.
* Next: inspect log, then treatment, analytic sample,
* Table 1, Figure 1, and Empirical Approach.
