*******************************************************
* ECON 352 Milestone 2
* Step 2A: Audit state minimum-wage changes
* IMPORTANT: This file DOES NOT lock in the final treatment rule.
* It creates clean evidence we will use to choose a treatment
* definition that responds to Prof. Blume-Kohout's feedback.
*******************************************************

clear all
set more off
capture log close

* 0. Project folder
cd "H:\Private\ECON 352\ECON352_Milestone2"

log using "02A_audit_minimum_wage_changes.log", text replace

*******************************************************
* 1. OPEN CLEAN MONTHLY MINIMUM-WAGE DATA
*******************************************************

use "mw_2010_2019_monthly_clean.dta", clear

* Create a Stata monthly date for easy sorting
gen tm = ym(year, month)
format tm %tm

sort statefip tm

*******************************************************
* 2. IDENTIFY EVERY MONTHLY INCREASE
*******************************************************

* Change from the prior month in the state's average minimum wage
by statefip: gen delta_mw = mean_mw - mean_mw[_n-1]

* Flag increases
gen byte mw_increase = delta_mw > .0001 if !missing(delta_mw)
replace mw_increase = 0 if missing(mw_increase)

label var delta_mw "Change in state minimum wage from prior month ($)"
label var mw_increase "State minimum wage increased this month"

*******************************************************
* 3. SAVE A LIST OF ALL INCREASE EVENTS
*******************************************************

preserve
    keep if mw_increase == 1
    keep statefip statename stateabb year month tm ///
         mean_mw delta_mw mean_fed_mw
    sort tm stateabb

    list statename stateabb year month mean_mw delta_mw, ///
        noobs sepby(year)

    export delimited using "mw_increase_events_2010_2019.csv", replace
restore

*******************************************************
* 4. CREATE ONE-ROW-PER-STATE SUMMARY
*******************************************************

* January 2010 wage
gen jan2010 = mean_mw if year == 2010 & month == 1
bysort statefip: egen mw_jan2010 = max(jan2010)

* December 2019 wage
gen dec2019 = mean_mw if year == 2019 & month == 12
bysort statefip: egen mw_dec2019 = max(dec2019)

* Number of increases during 2010-2019
bysort statefip: egen n_increases = total(mw_increase)

* First increase in the sample
bysort statefip: egen first_increase_tm = ///
    min(cond(mw_increase == 1, tm, .))
format first_increase_tm %tm

* Largest single monthly increase
bysort statefip: egen largest_increase = max(delta_mw)

egen tag_state = tag(statefip)

preserve
    keep if tag_state
    keep statefip statename stateabb mw_jan2010 mw_dec2019 ///
         n_increases first_increase_tm largest_increase
    sort first_increase_tm stateabb

    list statename stateabb mw_jan2010 mw_dec2019 ///
         n_increases first_increase_tm largest_increase, ///
         noobs sep(0)

    export delimited using "state_mw_summary_2010_2019.csv", replace
restore

*******************************************************
* 5. BASIC CHECKS
*******************************************************

count if tag_state
summarize n_increases largest_increase if tag_state

tab n_increases if tag_state

log close
