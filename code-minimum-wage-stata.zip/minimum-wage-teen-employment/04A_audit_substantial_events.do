*******************************************************
* ECON 352 Milestone 3
* Step 4A: Audit substantial minimum-wage increases
*******************************************************

clear all
set more off
capture log close

cd "H:\Private\ECON 352\ECON352_Milestone2"

log using "04A_check_substantial_events.log", text replace

*******************************************************
* 1. OPEN CLEAN MERGED MASTER DATA
*******************************************************

use "teen_cps_mw_merged_2010_2019.dta", clear

keep statefip statename stateabb year month ///
     min_mw mean_mw max_mw ///
     min_fed_mw mean_fed_mw max_fed_mw

duplicates drop statefip year month, force
isid statefip year month

gen tm = ym(year, month)
format tm %tm
sort statefip tm

*******************************************************
* 2. CALCULATE MINIMUM-WAGE CHANGES
*******************************************************

by statefip: gen mw_change = min_mw - min_mw[_n-1]

label var mw_change ///
    "Change in effective minimum wage from prior month ($)"

gen byte substantial25 = mw_change >= .2499 if !missing(mw_change)
replace substantial25 = 0 if missing(substantial25)

gen byte substantial50 = mw_change >= .4999 if !missing(mw_change)
replace substantial50 = 0 if missing(substantial50)

*******************************************************
* 3. FIND FIRST SUBSTANTIAL INCREASE IN EACH STATE
*******************************************************

bysort statefip: egen first25_tm = ///
    min(cond(substantial25 == 1, tm, .))
format first25_tm %tm

bysort statefip: egen first50_tm = ///
    min(cond(substantial50 == 1, tm, .))
format first50_tm %tm

gen first25_change_obs = mw_change if tm == first25_tm

bysort statefip: egen first25_change = ///
    max(first25_change_obs)

*******************************************************
* 4. DEFINE CLEAN CONTROL STATES
*******************************************************

bysort statefip: egen byte ever25 = max(substantial25)

gen byte clean_control25 = (ever25 == 0)

label var clean_control25 ///
    "No >=$0.25 MW increase in 2010-2019"

*******************************************************
* 5. CHECK 24 MONTHS BEFORE AND AFTER TREATMENT
*******************************************************

local sample_start = ym(2010,1)
local sample_end   = ym(2019,12)

gen byte eligible_24m = ///
    !missing(first25_tm) & ///
    first25_tm - 24 >= `sample_start' & ///
    first25_tm + 24 <= `sample_end'

label var eligible_24m ///
    "First >=$0.25 event has 24m pre and 24m post"

*******************************************************
* 6. STATE-LEVEL SUMMARY
*******************************************************

egen tag_state = tag(statefip)

display "=================================================="
display "STATE-LEVEL CHECKS"
display "=================================================="

count if tag_state
display "Total jurisdictions = " r(N)

count if tag_state & ever25 == 1
display "States/DC with >=$0.25 increase = " r(N)

count if tag_state & clean_control25 == 1
display "Clean controls = " r(N)

count if tag_state & eligible_24m == 1
display "Eligible treated states with balanced 24m window = " r(N)

preserve

keep if tag_state

keep statefip statename stateabb first25_tm ///
     first25_change ever25 clean_control25 ///
     eligible_24m first50_tm

sort first25_tm stateabb

list statename stateabb first25_tm ///
     first25_change clean_control25 ///
     eligible_24m, noobs sep(0)

export delimited using ///
    "M3_state_treatment_summary.csv", replace

restore

*******************************************************
* 7. LIST ALL >= $0.25 EVENTS
*******************************************************

preserve

keep if substantial25 == 1

keep statefip statename stateabb year month ///
     tm min_mw mw_change

sort tm stateabb

list statename stateabb year month ///
     min_mw mw_change, noobs sepby(year)

export delimited using ///
    "M3_all_increases_ge25.csv", replace

restore

*******************************************************
* 8. LIST ELIGIBLE FIRST EVENTS
*******************************************************

preserve

keep if tag_state & eligible_24m == 1

keep statefip statename stateabb ///
     first25_tm first25_change

sort first25_tm stateabb

list statename stateabb first25_tm ///
     first25_change, noobs

export delimited using ///
    "M3_eligible_first_events_ge25.csv", replace

restore

log close
