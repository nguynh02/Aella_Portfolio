MINIMUM WAGE INCREASES AND TEEN EMPLOYMENT
Stata code and results. Aella Nguyen, ECON 352, Fall 2026.

QUESTION
What is the causal effect of state minimum-wage increases of at least $0.25
on employment among teenagers ages 16-19?

FILES, IN RUN ORDER
  cps_00001.txt                       IPUMS command file that reads the CPS extract
  01_build_merged_data.do             Import CPS, keep civilian teens 16-19, merge monthly
                                      state minimum wages
  02A_audit_minimum_wage_changes.do   Audit every state minimum-wage change, 2010-2019
  04A_audit_substantial_events.do     Find increases of at least $0.25 and clean controls
  04C_build_final_clean_stack.do      Build the stacked sample: 33 treated state-events,
                                      11 cohorts, 10,008 state-months, corrective weights
  05_stacked_did_event_study.do       Stacked DiD (Models 1 and 2), wild cluster bootstrap,
                                      event study and pre-trend tests

  Step 04B, which collapses the person-level CPS data into the state-month panel
  read by 04C (M3_state_month_panel.dta), is not part of this package.

RESULTS (results/)
  05B_main_regression_results.csv     Main estimates, Models 1 and 2
  05B_eventstudy_results.csv          Event-study coefficients, months -12 to +11
  M3_final_treated_events_ge25.csv    The 33 treated state-events
  M3_state_treatment_summary.csv      First increase of at least $0.25 by state

KEY RESULTS
  Model 1: +0.109 percentage points (state-clustered SE 0.499),
           wild cluster bootstrap p = 0.830
  Model 2 (+ demographic controls): +0.106 pp, wild bootstrap p = 0.836
  Pre-trend joint test, months -12 to -2: wild bootstrap p = 0.410
  No detectable short-run effect on teen employment.

DATA (not included)
  IPUMS CPS Basic Monthly, 2010-2019 (Flood et al. 2025), from cps.ipums.org.
  Vaghul and Zipperer (2022), Historical state and sub-state minimum wages, v1.4.0.
