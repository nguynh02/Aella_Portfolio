*******************************************************
* ECON 352 Milestone 3
* Step 5: Main stacked DiD results + event study
*
* FINAL ANALYSIS:
* Model 1 (main):
*   emp_rate on treat_post
*   + state-by-stack fixed effects
*   + calendar-month-by-stack fixed effects
*
* Model 2 (robustness):
*   same model + female and age composition controls
*
* Inference:
*   - conventional SEs clustered by state
*   - wild cluster bootstrap p-values by state
*
* Event study:
*   - monthly event-time indicators from -12 to +11
*   - month -1 omitted as reference period
*******************************************************

clear all
set more off
capture log close

cd "H:\Private\ECON 352\ECON352_Milestone2"

log using "05B_main_results_eventstudy.log", text replace

*******************************************************
* 0. MAKE SURE BOOTTEST IS AVAILABLE
*******************************************************

* Stata 17 compatibility:
* The newest SSC boottest build may contain a Mata library compiled
* under a newer Stata version. Pin version 3.0.2, which the official
* boottest help file provides as a directly installable older release.

capture ado uninstall boottest

net install boottest, replace ///
    from("https://raw.github.com/droodman/boottest/v3.0.2")

which boottest

*******************************************************
* 1. OPEN FINAL CLEAN STACKED SAMPLE
*******************************************************

use "M3_stacked_DiD_final_clean12.dta", clear

count
display "Expected analysis rows = 10,008. Actual = " r(N)

egen state_tag_check = tag(statefip)
count if state_tag_check
display "Expected unique states/DC = 51. Actual = " r(N)
drop state_tag_check

*******************************************************
* 2. MAIN STACKED DID: MODEL 1
*    No demographic composition controls
*******************************************************

display "=================================================="
display "MODEL 1: MAIN STACKED DID"
display "=================================================="

reg emp_rate ///
    treat_post ///
    i.state_stack ///
    i.time_stack ///
    [pw=stack_weight], ///
    vce(cluster statefip)

scalar b1  = _b[treat_post]
scalar se1 = _se[treat_post]
scalar pcluster1 = 2*ttail(e(df_r), abs(b1/se1))
scalar N1 = e(N)
scalar clusters1 = e(N_clust)

display "Main coefficient = " %9.6f b1
display "Clustered SE = " %9.6f se1
display "Clustered p-value = " %9.6f pcluster1
display "Effect in percentage points = " %9.3f (100*b1)

* Wild cluster bootstrap inference
boottest treat_post, ///
    cluster(statefip) ///
    reps(9999) ///
    seed(3522026) ///
    nograph

scalar pwild1 = r(p)

display "Wild-cluster-bootstrap p-value = " %9.6f pwild1

*******************************************************
* 3. MODEL 2: ADD DEMOGRAPHIC COMPOSITION CONTROLS
*******************************************************

display "=================================================="
display "MODEL 2: WITH DEMOGRAPHIC COMPOSITION CONTROLS"
display "=================================================="

reg emp_rate ///
    treat_post ///
    female_share ///
    age17_share age18_share age19_share ///
    i.state_stack ///
    i.time_stack ///
    [pw=stack_weight], ///
    vce(cluster statefip)

scalar b2  = _b[treat_post]
scalar se2 = _se[treat_post]
scalar pcluster2 = 2*ttail(e(df_r), abs(b2/se2))
scalar N2 = e(N)
scalar clusters2 = e(N_clust)

display "Controlled coefficient = " %9.6f b2
display "Clustered SE = " %9.6f se2
display "Clustered p-value = " %9.6f pcluster2
display "Effect in percentage points = " %9.3f (100*b2)

boottest treat_post, ///
    cluster(statefip) ///
    reps(9999) ///
    seed(3522027) ///
    nograph

scalar pwild2 = r(p)

display "Wild-cluster-bootstrap p-value = " %9.6f pwild2

*******************************************************
* 4. EXPORT MAIN RESULTS FOR MANUSCRIPT TABLE
*******************************************************

tempfile mainresults
tempname mainhandle

postfile `mainhandle' ///
    str35 model ///
    double coefficient ///
    double clustered_se ///
    double clustered_p ///
    double wild_bootstrap_p ///
    double observations ///
    double state_clusters ///
    using `mainresults', replace

post `mainhandle' ///
    ("Model 1: Main stacked DiD") ///
    (b1) (se1) (pcluster1) (pwild1) (N1) (clusters1)

post `mainhandle' ///
    ("Model 2: + demographic controls") ///
    (b2) (se2) (pcluster2) (pwild2) (N2) (clusters2)

postclose `mainhandle'

preserve
    use `mainresults', clear

    gen effect_percentage_points = 100*coefficient

    order model coefficient effect_percentage_points ///
          clustered_se clustered_p wild_bootstrap_p ///
          observations state_clusters

    list, noobs

    export delimited using ///
        "05B_main_regression_results.csv", replace
restore

*******************************************************
* 5. CREATE MONTHLY EVENT-STUDY VARIABLES
*
* Reference period = event month -1.
*******************************************************

* Pre-treatment months: -12 through -2
forvalues k = 12(-1)2 {
    gen byte lead`k' = ///
        (treat == 1 & event_time == -`k')
}

* Treatment month 0
gen byte event0 = ///
    (treat == 1 & event_time == 0)

* Post-treatment months +1 through +11
forvalues k = 1/11 {
    gen byte lag`k' = ///
        (treat == 1 & event_time == `k')
}

*******************************************************
* 6. EVENT-STUDY REGRESSION
*
* No demographic controls in the main event study.
* Month -1 is omitted.
*******************************************************

display "=================================================="
display "EVENT STUDY: REFERENCE MONTH = -1"
display "=================================================="

reg emp_rate ///
    lead12 lead11 lead10 lead9 lead8 lead7 ///
    lead6 lead5 lead4 lead3 lead2 ///
    event0 ///
    lag1 lag2 lag3 lag4 lag5 lag6 ///
    lag7 lag8 lag9 lag10 lag11 ///
    i.state_stack ///
    i.time_stack ///
    [pw=stack_weight], ///
    vce(cluster statefip)

*******************************************************
* 7. JOINT PRE-TREND TEST
*******************************************************

display "=================================================="
display "PRE-TREND TEST: ALL LEADS -12 TO -2 = 0"
display "=================================================="

test ///
    lead12 lead11 lead10 lead9 lead8 lead7 ///
    lead6 lead5 lead4 lead3 lead2

scalar pretrend_cluster_p = r(p)

display "Conventional clustered joint pre-trend p-value = " ///
    %9.6f pretrend_cluster_p

boottest ///
    lead12 lead11 lead10 lead9 lead8 lead7 ///
    lead6 lead5 lead4 lead3 lead2, ///
    cluster(statefip) ///
    reps(9999) ///
    seed(3522028) ///
    nograph

scalar pretrend_wild_p = r(p)

display "Wild-bootstrap joint pre-trend p-value = " ///
    %9.6f pretrend_wild_p

*******************************************************
* 8. EXPORT EVENT-STUDY COEFFICIENTS
*******************************************************

tempfile esresults
tempname eshandle

postfile `eshandle' ///
    int event_time ///
    double coefficient ///
    double clustered_se ///
    double ci_low ///
    double ci_high ///
    using `esresults', replace

* Leads -12 through -2
forvalues k = 12(-1)2 {

    scalar btmp = _b[lead`k']
    scalar setmp = _se[lead`k']

    post `eshandle' ///
        (-`k') ///
        (btmp) ///
        (setmp) ///
        (btmp - 1.96*setmp) ///
        (btmp + 1.96*setmp)
}

* Reference month -1
post `eshandle' (-1) (0) (0) (0) (0)

* Treatment month 0
scalar btmp = _b[event0]
scalar setmp = _se[event0]

post `eshandle' ///
    (0) ///
    (btmp) ///
    (setmp) ///
    (btmp - 1.96*setmp) ///
    (btmp + 1.96*setmp)

* Lags +1 through +11
forvalues k = 1/11 {

    scalar btmp = _b[lag`k']
    scalar setmp = _se[lag`k']

    post `eshandle' ///
        (`k') ///
        (btmp) ///
        (setmp) ///
        (btmp - 1.96*setmp) ///
        (btmp + 1.96*setmp)
}

postclose `eshandle'

*******************************************************
* 9. CREATE EVENT-STUDY FIGURE
*******************************************************

preserve

    use `esresults', clear
    sort event_time

    gen coefficient_pp = 100*coefficient
    gen ci_low_pp = 100*ci_low
    gen ci_high_pp = 100*ci_high

    export delimited using ///
        "05B_eventstudy_results.csv", replace

    twoway ///
        (rcap ci_low_pp ci_high_pp event_time) ///
        (scatter coefficient_pp event_time), ///
        xline(-0.5, lpattern(dash)) ///
        yline(0, lpattern(solid)) ///
        xlabel(-12(1)11, labsize(small)) ///
        xtitle("Months Relative to Minimum-Wage Increase") ///
        ytitle("Effect on Teen Employment (percentage points)") ///
        title("Figure 2. Event-Study Estimates") ///
        subtitle("Substantial Minimum-Wage Increases of at Least $0.25") ///
        note("Reference period is month -1. 95% confidence intervals use state-clustered SEs.") ///
        legend(off) ///
        graphregion(color(white))

    graph export ///
        "05B_Figure2_event_study.png", ///
        width(2400) replace

restore

*******************************************************
* 10. FINAL SUMMARY TO LOG
*******************************************************

display "=================================================="
display "FINAL RESULTS SUMMARY"
display "=================================================="

display "MODEL 1 coefficient: " %9.6f b1
display "MODEL 1 effect (pp): " %9.3f (100*b1)
display "MODEL 1 clustered SE: " %9.6f se1
display "MODEL 1 clustered p: " %9.6f pcluster1
display "MODEL 1 wild-bootstrap p: " %9.6f pwild1

display "--------------------------------------------------"

display "MODEL 2 coefficient: " %9.6f b2
display "MODEL 2 effect (pp): " %9.3f (100*b2)
display "MODEL 2 clustered SE: " %9.6f se2
display "MODEL 2 clustered p: " %9.6f pcluster2
display "MODEL 2 wild-bootstrap p: " %9.6f pwild2

display "--------------------------------------------------"

display "Pre-trend clustered joint p: " ///
    %9.6f pretrend_cluster_p

display "Pre-trend wild-bootstrap joint p: " ///
    %9.6f pretrend_wild_p

display "=================================================="

log close
