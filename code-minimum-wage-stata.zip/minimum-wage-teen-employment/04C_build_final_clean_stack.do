*******************************************************
* ECON 352 Milestone 3
* Step 4C: Final clean stacked-DiD sample
*
* WHY THIS REVISION?
* The 24-month post window in Step 4B included many states
* that received another >=$0.25 minimum-wage increase.
* That makes it hard to interpret the coefficient as the
* short-run effect of one substantial increase.
*
* FINAL MAIN DESIGN:
* - Substantial event: effective minimum wage rises >= $0.25.
* - Event start: no other >=$0.25 increase in prior 24 months.
*   This avoids counting annual phase-ins as separate new events.
* - Clean event: no additional >=$0.25 increase during the
*   following 11 months.
* - Event window: 12 months before (-12 to -1) and
*   12 months after (0 to +11).
* - Clean controls: no >=$0.25 increase anywhere in the same
*   24-month event window.
* - Corrective stacked-DiD weights follow Wing et al.
*
* This file only builds/checks the final sample.
* It does NOT estimate the final regression yet.
*******************************************************

clear all
set more off
capture log close

cd "H:\Private\ECON 352\ECON352_Milestone2"

log using "04C_build_final_clean_stack.log", text replace

*******************************************************
* 1. OPEN STATE-MONTH PANEL CREATED IN STEP 4B
*******************************************************

use "M3_state_month_panel.dta", clear

count
display "State-month panel rows should equal 6,120: " r(N)

isid statefip year month
sort statefip tm

*******************************************************
* 2. IDENTIFY STARTS OF DISTINCT >= $0.25 EVENTS
*
* A new event cannot have another >=$0.25 increase
* in the previous 24 months.
*******************************************************

gen byte prior25_within24 = 0

forvalues h = 1/24 {
    by statefip (tm): replace prior25_within24 = 1 ///
        if _n > `h' & substantial25[_n-`h'] == 1
}

gen byte event_start25 = ///
    (substantial25 == 1 & prior25_within24 == 0)

label var event_start25 ///
    "Start of distinct >=$0.25 minimum-wage event"

*******************************************************
* 3. REQUIRE A CLEAN 12-MONTH POST PERIOD
*
* Drop focal events followed by another >=$0.25 increase
* within months +1 through +11.
*******************************************************

gen byte future25_within11 = 0

forvalues h = 1/11 {
    by statefip (tm): replace future25_within11 = 1 ///
        if _n <= _N-`h' & substantial25[_n+`h'] == 1
}

gen byte isolated_event25 = ///
    (event_start25 == 1 & future25_within11 == 0)

label var isolated_event25 ///
    "Distinct >=$0.25 event with clean following 11 months"

*******************************************************
* 4. REQUIRE COMPLETE -12 TO +11 WINDOW
*******************************************************

local sample_start = ym(2010,1)
local sample_end   = ym(2019,12)

gen byte eligible_event25 = ///
    isolated_event25 == 1 & ///
    tm - 12 >= `sample_start' & ///
    tm + 11 <= `sample_end'

label var eligible_event25 ///
    "Eligible clean event with 12m pre and 12m post"

*******************************************************
* 5. AUDIT FINAL EVENT SET
*******************************************************

count if eligible_event25 == 1
display "Eligible treated state-events should equal 33: " r(N)

levelsof tm if eligible_event25 == 1, local(cohorts)

display "Treatment cohort months:"
display "`cohorts'"

preserve
    keep if eligible_event25 == 1
    keep statefip statename stateabb year month tm mw_change
    sort tm stateabb

    list statename stateabb year month mw_change, ///
        noobs sepby(year)

    export delimited using ///
        "M3_final_treated_events_ge25.csv", replace
restore

*******************************************************
* 6. SAVE PANEL AS TEMPORARY MASTER
*******************************************************

tempfile panel stackall
save `panel', replace

local first_stack = 1

*******************************************************
* 7. BUILD ONE CLEAN SUB-EXPERIMENT PER COHORT
*******************************************************

foreach c of local cohorts {

    use `panel', clear

    * Treated states are eligible event-start states in cohort c
    bysort statefip: egen byte treat = ///
        max(eligible_event25 == 1 & tm == `c')

    * A control is clean only if it has NO >=$0.25 increase
    * anywhere from -12 through +11 around this cohort.
    gen byte event_in_window = ///
        (substantial25 == 1 & inrange(tm, `c'-12, `c'+11))

    bysort statefip: egen byte any_event_window = ///
        max(event_in_window)

    * Keep focal treated states + clean controls
    keep if treat == 1 | any_event_window == 0

    * Keep exactly 24 months: -12,...,-1,0,...,+11
    keep if inrange(tm, `c'-12, `c'+11)

    gen int stack = `c'
    format stack %tm

    gen int event_time = tm - `c'

    gen byte post = (event_time >= 0)
    gen byte treat_post = treat * post

    * Every state in each stack must have exactly 24 months
    bysort statefip: gen months_in_stack = _N
    assert months_in_stack == 24
    drop months_in_stack event_in_window any_event_window

    if `first_stack' == 1 {
        save `stackall', replace
        local first_stack = 0
    }
    else {
        append using `stackall'
        save `stackall', replace
    }
}

use `stackall', clear

*******************************************************
* 8. STACK-SPECIFIC FIXED-EFFECT IDS
*******************************************************

egen state_stack = group(stack statefip)
label var state_stack ///
    "State x treatment-cohort fixed-effect ID"

egen time_stack = group(stack tm)
label var time_stack ///
    "Calendar month x treatment-cohort fixed-effect ID"

*******************************************************
* 9. CORRECTIVE STACKED-DID WEIGHTS
*******************************************************

egen unit_tag = tag(stack statefip)

gen byte tag_treat = unit_tag & (treat == 1)
gen byte tag_control = unit_tag & (treat == 0)

bysort stack: egen n_treat_sub = total(tag_treat)
bysort stack: egen n_control_sub = total(tag_control)

egen n_treat_total = total(tag_treat)
egen n_control_total = total(tag_control)

gen double stack_weight = 1 if treat == 1

replace stack_weight = ///
    (n_treat_sub / n_treat_total) / ///
    (n_control_sub / n_control_total) ///
    if treat == 0

label var stack_weight ///
    "Corrective stacked-DiD weight"

*******************************************************
* 10. FINAL SAMPLE CHECKS
*******************************************************

display "=================================================="
display "FINAL CLEAN STACK CHECKS"
display "=================================================="

count
display "Stacked state-month rows should equal 10,008: " r(N)

egen stack_tag = tag(stack)
count if stack_tag
display "Treatment cohorts should equal 11: " r(N)

egen unique_state_tag = tag(statefip)
count if unique_state_tag
display "Unique states/DC should equal 51: " r(N)

count if unit_tag
display "State x cohort units should equal 417: " r(N)

count if tag_treat
display "Treated state-events should equal 33: " r(N)

count if missing(emp_rate, female_share, age17_share, ///
                 age18_share, age19_share, stack_weight)
display "Rows missing core variables should equal 0: " r(N)

summarize event_time
display "Event time must run from -12 to +11."

*******************************************************
* 11. STACK SUMMARY
*******************************************************

gen double control_weight_only = ///
    stack_weight if treat == 0

preserve
    keep if unit_tag

    collapse ///
        (sum) treated_states=treat ///
        (count) total_states=statefip ///
        (mean) control_weight=control_weight_only, ///
        by(stack)

    gen control_states = total_states - treated_states
    format stack %tm

    order stack treated_states control_states control_weight

    list stack treated_states control_states ///
         control_weight, noobs

    export delimited using ///
        "M3_final_stack_summary.csv", replace
restore

*******************************************************
* 12. QUICK DESCRIPTIVE CHECKS
*******************************************************

summarize emp_rate female_share ///
          age17_share age18_share age19_share

*******************************************************
* 13. SAVE FINAL ANALYSIS SAMPLE
*******************************************************

save "M3_stacked_DiD_final_clean12.dta", replace

log close
