"""
Checks that run in seconds: python3 tests/test_model.py
  1. The vectorized engine equals a plain per-vintage loop (the reference implementation)
  2. The SQL tie-out report has no FAIL rows
  3. The Excel feed rebuilds the Python 2027E depreciation exactly (same math as the workbook)
"""
import csv
import json
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'model'))
import depreciation_model as dm  # noqa: E402


def reference_run(p, add, life_2027_years=None):
    """Per-vintage loop: the slow, obvious version of dm.run."""
    life_2027_q = int(round(life_2027_years * 4)) if life_2027_years else None
    changes = {dm.IDX[(2021, 1)]: 17, dm.IDX[(2023, 1)]: 24}
    if life_2027_q:
        changes[dm.IDX[(2027, 1)]] = life_2027_q
    cipE = cipB = 0.0
    equip, other = [], []
    dep, cip = np.zeros(dm.T), np.zeros(dm.T)
    for t, (y, q) in enumerate(dm.QUARTERS):
        if t in changes:
            for v in equip:
                v['rem'] = max(changes[t] - (t - v['t0']), 1)
        A = add[t]
        aE, aO, aL = A * dm.equip_share(y, p), A * dm.OTHER_SHARE, A * dm.LAND_SHARE
        aB = A - aE - aO - aL
        placedE = p['pE'] * (cipE + aE); cipE = (1 - p['pE']) * (cipE + aE)
        placedB = p['pB'] * (cipB + aB); cipB = (1 - p['pB']) * (cipB + aB)
        cip[t] = cipE + cipB
        d = 0.0
        for v in equip + other:
            if v['nbv'] > 1e-9 and v['rem'] > 0:
                x = v['nbv'] / v['rem']; v['nbv'] -= x; v['rem'] -= 1; d += x
        dep[t] = d
        equip.append({'nbv': placedE, 'rem': dm.equip_life_q(y, life_2027_q), 't0': t})
        other.append({'nbv': placedB, 'rem': int(p['LB'] * 4), 't0': t})
        other.append({'nbv': aO, 'rem': dm.OTHER_LIFE_Q, 't0': t})
    return dep, cip


def test_engine_matches_reference():
    inp = dm.load_inputs()
    add = dm.build_additions(inp)
    for p in (dict(e0=0.5, e1=0.45, e2=0.55, e3=0.6, e4=0.65, pE=0.25, pB=0.08, LB=15),
              dict(e0=0.4, e1=0.55, e2=0.5, e3=0.5, e4=0.7, pE=0.4, pB=0.13, LB=25)):
        for life in (None, 5):
            dep_ref, cip_ref = reference_run(p, add, life)
            r = dm.run(p, add, life_2027_years=life)
            assert np.allclose(r['dep'], dep_ref, rtol=1e-9, atol=1e-6), 'depreciation differs from reference'
            assert np.allclose(r['cip'], cip_ref, rtol=1e-9, atol=1e-6), 'CIP differs from reference'


def test_tieout_has_no_fail():
    rows = list(csv.DictReader(open(ROOT / 'data' / 'processed' / 'tieout_report.csv')))
    assert rows and not [r for r in rows if r['status'] == 'FAIL'], 'tie-out has FAIL rows'


def excel_rebuild(feed):
    """The workbook's math: in-service run-off + CIP drain + new CapEx, quarter by quarter."""
    p, qs = feed['params'], list(feed['forecast_capex'])
    e, o, land = p['e4'], feed['other_share'], feed['land_share']
    LE, LB, LO = feed['life_equip_q'], feed['life_build_q'], feed['life_other_q']
    cE, cB = feed['cipE_open'], feed['cipB_open']
    cum_E = cum_B = cum_O = 0.0
    total = {}
    for qtr in qs:
        dep_new = cum_E / LE + cum_B / LB + cum_O / LO       # assets placed in earlier forecast quarters
        total[qtr] = feed['runoff'][qtr] + dep_new
        A = feed['forecast_capex'][qtr]
        aE, aO = A * e, A * o
        aB = A - aE - aO - A * land
        pE_, pB_ = p['pE'] * (cE + aE), p['pB'] * (cB + aB)
        cE, cB = cE + aE - pE_, cB + aB - pB_
        cum_E, cum_B, cum_O = cum_E + pE_, cum_B + pB_, cum_O + aO
    return total


def test_excel_feed_rebuilds_python():
    feed = json.loads((ROOT / 'model' / 'outputs' / 'excel_feed.json').read_text())
    rebuilt = excel_rebuild(feed)
    for qtr, v in feed['dep_total'].items():
        assert abs(rebuilt[qtr] - v) < 1e-6, f'Excel math differs from Python in {qtr}'


if __name__ == '__main__':
    for name, fn in list(globals().items()):
        if name.startswith('test_'):
            fn()
            print('PASS', name)
