"""
Build the Excel planning model from the Python outputs.

Reads  model/outputs/results.json, model/outputs/excel_feed.json, data/processed/*.csv
Writes excel/Alphabet_Depreciation_Margin_Model.xlsx

The workbook rebuilds the forward forecast (Q4 2026 to Q4 2028) with live formulas:
in-service run-off (from the Python vintage engine) + CIP going live + new CapEx.
At default inputs it ties to the Python model (see the Checks tab).
"""
import csv
import json
import pathlib

from openpyxl import Workbook
from openpyxl.chart import LineChart, Reference
from openpyxl.comments import Comment
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

ROOT = pathlib.Path(__file__).resolve().parents[1]
RES = json.loads((ROOT / 'model' / 'outputs' / 'results.json').read_text())
FEED = json.loads((ROOT / 'model' / 'outputs' / 'excel_feed.json').read_text())
QROWS = list(csv.DictReader(open(ROOT / 'data' / 'processed' / 'model_inputs_quarterly.csv')))
AROWS = {int(r['fiscal_year']): r for r in csv.DictReader(open(ROOT / 'data' / 'processed' / 'model_inputs_annual.csv'))}
OUT = ROOT / 'excel' / 'Alphabet_Depreciation_Margin_Model.xlsx'

F = 'Arial'
BLUE, BLACK, GREEN = (Font(name=F, size=10, color=c) for c in ('0000FF', '000000', '008000'))
BOLD = Font(name=F, size=10, bold=True)
BOLD_GREEN = Font(name=F, size=10, bold=True, color='008000')
TITLE = Font(name=F, size=14, bold=True, color='1A73E8')
NOTE = Font(name=F, size=9, italic=True, color='595959')
HDR_FONT = Font(name=F, size=10, bold=True, color='FFFFFF')
HDR_FILL = PatternFill('solid', fgColor='1A73E8')
SEC_FILL = PatternFill('solid', fgColor='E8F0FE')
YELLOW = PatternFill('solid', fgColor='FFFF00')
TOTAL_BORDER = Border(top=Side(style='thin', color='808080'))
M = '#,##0;(#,##0);"-"'
M1 = '#,##0.0;(#,##0.0);"-"'
PCT = '0.0%;(0.0%);"-"'
SPCT = '+0.0%;-0.0%;0.0%'
QTRS = ['2026Q4', '2027Q1', '2027Q2', '2027Q3', '2027Q4', '2028Q1', '2028Q2', '2028Q3', '2028Q4']
QCOLS = ['D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L']          # forecast quarters, same columns on every engine tab
YEAR_OF = {c: int(q[:4]) for c, q in zip(QCOLS, QTRS)}
SRC_10Q = 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000084/goog-20260930.htm'
SRC_10K = 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/goog-20251231.htm'
SRC_CALL = 'https://s206.q4cdn.com/479360582/files/doc_events/2026/Oct/28/2026_Q3_Earnings_Transcript.pdf'
SRC_API = 'https://data.sec.gov/api/xbrl/companyconcept/CIK0001652044/us-gaap/'

wb = Workbook()
names = ['Cover', 'Inputs', 'Depreciation', 'Margin', 'Scenarios', 'Backtest', 'Data_SEC', 'Model_Feed', 'Checks']
ws = {n: (wb.active if i == 0 else wb.create_sheet()) for i, n in enumerate(names)}
for n, s in ws.items():
    s.title = n
    s.sheet_view.showGridLines = False


def put(sh, ref, value, font=BLACK, fmt=None, fill=None, bold=False, note=None, align=None):
    c = ws[sh][ref]
    c.value = value
    c.font = Font(name=F, size=font.size, bold=bold or font.bold, italic=font.italic, color=font.color)
    if fmt:
        c.number_format = fmt
    if fill:
        c.fill = fill
    if note:
        c.comment = Comment(note, 'Model')
    if align:
        c.alignment = Alignment(horizontal=align)
    return c


def title(sh, text, sub):
    put(sh, 'A1', text, TITLE)
    put(sh, 'A2', sub, NOTE)


def section(sh, row, text, last_col='P'):
    for col in range(1, ord(last_col) - 64 + 1):
        ws[sh].cell(row=row, column=col).fill = SEC_FILL
    put(sh, f'A{row}', text, BOLD, fill=SEC_FILL)


def header(sh, row, labels, start_col='A'):
    for i, lab in enumerate(labels):
        col = chr(ord(start_col) + i)
        if lab is None:
            continue
        put(sh, f'{col}{row}', lab, HDR_FONT, fill=HDR_FILL, align='center' if i else None)


def widths(sh, spec):
    for col, w in spec.items():
        ws[sh].column_dimensions[col].width = w


# ====================================================================== Data_SEC
S = 'Data_SEC'
title(S, 'Reported data from SEC filings ($M)',
      'Built by the SQL pipeline (sql/01-04) from SEC XBRL facts; Q3 2026 operating income hand-keyed from the 10-Q. Year-to-date facts turned into quarters.')
header(S, 4, ['Quarter', 'Year', 'Qtr', 'CapEx', 'Depreciation', 'Revenue', 'Operating income',
              'Costs other than depreciation', 'Operating margin', 'Depreciation % revenue', 'Note'])
DROW = {}
r = 5
for q in QROWS:
    if int(q['fiscal_year']) < 2021:
        continue
    DROW[q['quarter_label']] = r
    put(S, f'A{r}', q['quarter_label'])
    put(S, f'B{r}', int(q['fiscal_year']), fmt='0')
    put(S, f'C{r}', int(q['fiscal_quarter']), fmt='0')
    for col, key in (('D', 'capex_musd'), ('E', 'depreciation_musd'), ('F', 'revenue_musd'), ('G', 'operating_income_musd')):
        if q[key]:
            put(S, f'{col}{r}', float(q[key]), BLUE, M)
    put(S, f'H{r}', f'=IF(OR(E{r}="",F{r}=""),"",F{r}-G{r}-E{r})', fmt=M)
    put(S, f'I{r}', f'=IF(F{r}="","",G{r}/F{r})', fmt=PCT)
    put(S, f'J{r}', f'=IF(OR(E{r}="",F{r}=""),"",E{r}/F{r})', fmt=PCT)
    if q['flags']:
        put(S, f'K{r}', q['flags'], NOTE)
    r += 1
Q_FIRST, Q_LAST = 5, r - 1
QR = lambda col: f'Data_SEC!${col}${Q_FIRST}:${col}${Q_LAST}'
put(S, f'A{Q_LAST + 1}', 'Depreciation is reported quarterly in XBRL from 2023; 2021-2022 are full-year only.', NOTE)

a0 = Q_LAST + 3
section(S, a0, 'Full year (XBRL full-year facts)', 'K')
header(S, a0 + 1, ['Year', None, None, 'CapEx', 'Depreciation', 'Revenue', 'Operating income',
                   'Costs other than depreciation', 'Operating margin', 'Depreciation % revenue', 'CapEx / depreciation'])
AROW = {}
for i, y in enumerate(range(2021, 2026)):
    rr = a0 + 2 + i
    AROW[y] = rr
    a = AROWS[y]
    put(S, f'A{rr}', str(y))
    for col, key in (('D', 'capex_musd'), ('E', 'depreciation_musd'), ('F', 'revenue_musd'), ('G', 'operating_income_musd')):
        put(S, f'{col}{rr}', float(a[key]), BLUE, M)
    put(S, f'H{rr}', f'=F{rr}-G{rr}-E{rr}', fmt=M)
    put(S, f'I{rr}', f'=G{rr}/F{rr}', fmt=PCT)
    put(S, f'J{rr}', f'=E{rr}/F{rr}', fmt=PCT)
    put(S, f'K{rr}', f'=D{rr}/E{rr}', fmt='0.0"x"')

c0 = a0 + 9
section(S, c0, '10-Q control totals, 9M 2026 (hand-keyed for the tie-out checks)', 'K')
CTRL = {}
for i, (lab, val, key) in enumerate((('CapEx (cash flow statement)', 131953, 'capex'),
                                      ('Depreciation (cash flow statement)', 21955, 'dep'),
                                      ('Revenue (income statement)', 357269, 'rev'),
                                      ('Operating income (income statement)', 121042, 'oi'))):
    rr = c0 + 1 + i
    CTRL[key] = f'Data_SEC!$D${rr}'
    put(S, f'A{rr}', lab)
    put(S, f'D{rr}', val, BLUE, M, note=f'Alphabet 10-Q, Q3 2026: {SRC_10Q}')
put(S, f'A{c0 + 6}', f'Sources: SEC XBRL API ({SRC_API}<tag>.json), pulled 2026-11-08; Alphabet 10-Q Q3 2026 ({SRC_10Q})', NOTE)
widths(S, {'A': 14, 'B': 7, 'C': 6, 'D': 12, 'E': 13, 'F': 12, 'G': 15, 'H': 16, 'I': 12, 'J': 13, 'K': 34})
ws[S].freeze_panes = 'D5'

SUM26 = lambda col: f'SUMIFS({QR(col)},{QR("B")},2026)'
Q425 = lambda col: f'Data_SEC!${col}${DROW["2025Q4"]}'

# ====================================================================== Model_Feed
S = 'Model_Feed'
title(S, 'Python model feed ($M)',
      'Written by model/depreciation_model.py (vintage engine, full fit through Q3 2026). These values describe the asset base the workbook does not rebuild. Re-run Python after each filing.')
section(S, 4, 'Calibrated parameters (full fit; defaults on the Inputs tab)', 'L')
P = RES['params_full']
plabels = [('e0', 'Servers and network share of spend, before 2018'), ('e1', 'Share, 2018-2020'), ('e2', 'Share, 2021-2023'),
           ('e3', 'Share, 2024-2025'), ('e4', 'Share, 2026 onward (anchored to CFO disclosure)'),
           ('pE', 'Go-live rate, servers and network (per quarter)'), ('pB', 'Go-live rate, buildings (per quarter)'),
           ('LB', 'Building life (years)')]
for i, (k, lab) in enumerate(plabels):
    put(S, f'A{5 + i}', lab)
    put(S, f'C{5 + i}', P[k], BLUE, '0' if k == 'LB' else '0%')
section(S, 14, 'Opening balances at Sep 30, 2026', 'L')
put(S, 'A15', 'Construction in progress, servers and network (model)')
put(S, 'C15', FEED['cipE_open'], BLUE, M)
put(S, 'A16', 'Construction in progress, buildings (model)')
put(S, 'C16', FEED['cipB_open'], BLUE, M)
put(S, 'A17', 'Construction in progress, total (model)')
put(S, 'C17', '=C15+C16', fmt=M)
put(S, 'A18', 'Construction in progress, reported (10-Q)')
put(S, 'C18', 145270, BLUE, M, note=f'Alphabet 10-Q, Q3 2026, property and equipment note: {SRC_10Q}')
put(S, 'A19', 'Model vs reported')
put(S, 'C19', '=C17/C18-1', fmt=SPCT)
section(S, 21, 'Depreciation run-off of assets in service at Sep 30, 2026 (no new spend, no life change)', 'L')
header(S, 22, ['Quarter', None, None] + QTRS)
put(S, 'A23', 'In-service run-off')
for c, q in zip(QCOLS, QTRS):
    put(S, f'{c}23', FEED['runoff'][q], BLUE, M)
section(S, 25, 'Python reference outputs (base case, default inputs)', 'L')
f = RES['forecast']
REF = {}
refs = [('dep26', '2026E depreciation', f['dep_2026E']), ('dep27', '2027E depreciation', f['dep_2027E']),
        ('dep28', '2028E depreciation', f['dep_2028E']), ('lock27', '2027E locked in', f['locked_2027']),
        ('life27', 'Useful life 6 to 5 years from Jan 2027: 2027E impact', f['life_risk_2027']),
        ('life28', 'Useful life 6 to 5 years from Jan 2027: 2028E impact', f['life_risk_2028']),
        ('mix60', '2027E depreciation if servers take 60% of 2026+ spend', RES['e4_sensitivity_dep_2027']['0.60']),
        ('mix70', '2027E depreciation if servers take 70% of 2026+ spend', RES['e4_sensitivity_dep_2027']['0.70'])]
for i, (k, lab, v) in enumerate(refs):
    rr = 26 + i
    REF[k] = f'Model_Feed!$C${rr}'
    put(S, f'A{rr}', lab)
    put(S, f'C{rr}', v, BLUE, M)
widths(S, {'A': 58, 'B': 2, 'C': 13, **{c: 11 for c in QCOLS}})

# ====================================================================== Inputs
S = 'Inputs'
title(S, 'Inputs and assumptions ($M)', 'Blue = input. Yellow = scenario lever. Black = formula. Green = link to another tab.')
header(S, 3, ['Assumption', 'Value', 'Unit', 'Source or note'])
I = {}


def inp(row, key, label, value, unit, note, font=BLUE, fmt=M, fill=None):
    I[key] = f'Inputs!$B${row}'
    put(S, f'A{row}', label)
    put(S, f'B{row}', value, font, fmt, fill)
    put(S, f'C{row}', unit, NOTE)
    put(S, f'D{row}', note, NOTE)


section(S, 4, '1. Scenario', 'D')
inp(5, 'case', '2027 CapEx case (1 = Low, 2 = Base, 3 = High)', 2, 'case', 'Pick a case; every tab updates', fmt='0', fill=YELLOW)
inp(6, 'case_name', 'Selected case', '=CHOOSE(B5,"Low","Base","High")', '', '', BLACK, None)
dv = DataValidation(type='list', formula1='"1,2,3"', allow_blank=False)
ws[S].add_data_validation(dv)
dv.add('B5')
section(S, 8, '2. CapEx', 'D')
inp(9, 'g26_lo', 'FY2026 CapEx guidance, low', 195000, '$M', 'Alphabet Q3 2026 earnings call (CFO)')
inp(10, 'g26_hi', 'FY2026 CapEx guidance, high', 205000, '$M', 'Raised from $180-190B in July 2026')
inp(11, 'g26_mid', 'FY2026 CapEx, guidance midpoint', '=AVERAGE(B9:B10)', '$M', '', BLACK)
inp(12, 'capex9m', '9M 2026 CapEx, reported', f'={SUM26("D")}', '$M', 'Data_SEC tab', GREEN)
inp(13, 'capex_q4', 'Q4 2026 CapEx, implied by guidance', '=B11-B12', '$M', '', BLACK)
inp(14, 'c27_lo', '2027 CapEx, Low case', 250000, '$M', '+25% vs 2026 midpoint')
inp(15, 'c27_base', '2027 CapEx, Base case', 300000, '$M', 'Company: "significant increase". Public analyst views $300B+ (Yorkville ~$315B)')
inp(16, 'c27_hi', '2027 CapEx, High case', 350000, '$M', '+75% vs 2026 midpoint')
inp(17, 'c27', '2027 CapEx, selected case', '=CHOOSE(B5,B14,B15,B16)', '$M', '', BLACK)
inp(18, 'c27_g', '2027 CapEx growth vs FY2026 midpoint', '=B17/B11-1', '%', '', BLACK, PCT)
for i, (q, w) in enumerate(zip(('Q1', 'Q2', 'Q3', 'Q4'), RES['assumptions']['capex_2027_quarter_weights'])):
    inp(19 + i, f'w{i + 1}', f'2027 CapEx phasing, {q}', w, '% of year', 'Spend ramps through the year' if i == 0 else '', fmt=PCT)
inp(23, 'w_sum', 'Phasing total (must be 100%)', '=SUM(B19:B22)', '%', '', BLACK, PCT)
inp(24, 'g28', '2028 CapEx growth vs 2027', RES['assumptions']['capex_2028_growth'], '%', 'Placeholder; drives 2028E only', fmt=PCT)
section(S, 26, '3. Asset mix, timing and lives (calibrated in Python; flex to test)', 'D')
inp(27, 'e', 'Servers and network share of spend, 2026 onward', P['e4'], '% of spend',
    'CFO, Q3 2026 call: about 65% of technical infrastructure spend', fmt=PCT)
inp(28, 'o', 'Other assets share of spend (about 7-year life)', FEED['other_share'], '% of spend', 'Model assumption', fmt=PCT)
inp(29, 'land', 'Land share of spend (not depreciated)', FEED['land_share'], '% of spend', 'Model assumption', fmt=PCT)
inp(30, 'b', 'Buildings and data centers share of spend', '=1-B27-B28-B29', '% of spend', '', BLACK, PCT)
inp(31, 'pE', 'Go-live rate, servers and network', P['pE'], 'per quarter', 'Calibrated: about 3 quarters from spend to service on average', fmt=PCT)
inp(32, 'pB', 'Go-live rate, buildings', P['pB'], 'per quarter', 'Calibrated: about 9 quarters on average', fmt=PCT)
inp(33, 'LE', 'Useful life, servers and network', FEED['life_equip_q'], 'quarters', '6 years, Alphabet policy since Jan 2023 (10-K)', fmt='0')
inp(34, 'LB', 'Useful life, buildings and data centers', FEED['life_build_q'], 'quarters', '15 years, calibrated blended life', fmt='0')
inp(35, 'LO', 'Useful life, other assets', FEED['life_other_q'], 'quarters', '7 years, model assumption', fmt='0')
section(S, 37, '4. P&L', 'D')
A = RES['assumptions']
inp(38, 'rq4', 'Q4 2026 revenue growth, year over year', A['q4_2026_revenue_growth_yoy'], '%', 'Q3 2026 was +24.7%', fmt=PCT)
inp(39, 'cq4', 'Q4 2026 growth in costs other than depreciation, year over year', A['q4_2026_nondep_cost_growth_yoy'], '%', 'Q3 2026 was +20.0%', fmt=PCT)
inp(40, 'r27', '2027 revenue growth', 0.19, '%', 'Base: a modest slowdown from 2026E (+23.2%)', fmt=PCT)
inp(41, 'c27g', '2027 growth in costs other than depreciation', 0.189, '%', 'Default = 2026E pace (18.9%). The Margin tab shows the guardrail', fmt=PCT)
widths(S, {'A': 58, 'B': 13, 'C': 12, 'D': 70})
ws[S].freeze_panes = 'A4'

# ====================================================================== engine helper (Depreciation and Scenarios)


def engine(sh, r0, capex_cells, label):
    """Writes spend split + new-spend CIP engine starting at row r0. Returns dict of row numbers.
    capex_cells: dict col -> formula for CapEx in that quarter."""
    R = {}
    rows = ['capex', 'srv', 'bld', 'oth', 'land']
    labels = {'capex': f'CapEx, cash ({label})', 'srv': 'Servers and network', 'bld': 'Buildings and data centers',
              'oth': 'Other assets', 'land': 'Land (not depreciated)'}
    shares = {'srv': I['e'], 'bld': I['b'], 'oth': I['o'], 'land': I['land']}
    for i, k in enumerate(rows):
        R[k] = r0 + i
        put(sh, f'A{R[k]}', labels[k], BOLD if k == 'capex' else BLACK)
        for c in QCOLS:
            put(sh, f'{c}{R[k]}', capex_cells[c] if k == 'capex' else f'={c}{R["capex"]}*{shares[k]}', GREEN if k == 'capex' else BLACK, M)
    return R


def new_spend_block(sh, r0, R, title_text):
    section(sh, r0, title_text)
    keys = ['cipE_s', 'liveE', 'cipE_e', 'cipB_s', 'liveB', 'cipB_e', 'cumE', 'cumB', 'cumO', 'depN']
    lab = {'cipE_s': 'Construction in progress, servers and network, start', 'liveE': 'Goes live, servers and network',
           'cipE_e': 'Construction in progress, servers and network, end', 'cipB_s': 'Construction in progress, buildings, start',
           'liveB': 'Goes live, buildings', 'cipB_e': 'Construction in progress, buildings, end',
           'cumE': 'Cumulative gone live, servers and network', 'cumB': 'Cumulative gone live, buildings',
           'cumO': 'Cumulative other assets', 'depN': 'Depreciation of new spend'}
    for i, k in enumerate(keys):
        R[k] = r0 + 1 + i
        put(sh, f'A{R[k]}', lab[k], BOLD if k == 'depN' else BLACK)
    for k in ('cipE_e', 'cipB_e', 'cumE', 'cumB', 'cumO'):
        put(sh, f'C{R[k]}', 0, BLUE, M)
    prev = 'C'
    for c in QCOLS:
        put(sh, f'{c}{R["cipE_s"]}', f'={prev}{R["cipE_e"]}', fmt=M)
        put(sh, f'{c}{R["liveE"]}', f'=({c}{R["cipE_s"]}+{c}{R["srv"]})*{I["pE"]}', fmt=M)
        put(sh, f'{c}{R["cipE_e"]}', f'={c}{R["cipE_s"]}+{c}{R["srv"]}-{c}{R["liveE"]}', fmt=M)
        put(sh, f'{c}{R["cipB_s"]}', f'={prev}{R["cipB_e"]}', fmt=M)
        put(sh, f'{c}{R["liveB"]}', f'=({c}{R["cipB_s"]}+{c}{R["bld"]})*{I["pB"]}', fmt=M)
        put(sh, f'{c}{R["cipB_e"]}', f'={c}{R["cipB_s"]}+{c}{R["bld"]}-{c}{R["liveB"]}', fmt=M)
        put(sh, f'{c}{R["cumE"]}', f'={prev}{R["cumE"]}+{c}{R["liveE"]}', fmt=M)
        put(sh, f'{c}{R["cumB"]}', f'={prev}{R["cumB"]}+{c}{R["liveB"]}', fmt=M)
        put(sh, f'{c}{R["cumO"]}', f'={prev}{R["cumO"]}+{c}{R["oth"]}', fmt=M)
        put(sh, f'{c}{R["depN"]}', f'={prev}{R["cumE"]}/{I["LE"]}+{prev}{R["cumB"]}/{I["LB"]}+{prev}{R["cumO"]}/{I["LO"]}', BOLD, M)
        prev = c
    return R


def capex_formulas(case_cell):
    cells = {'D': f'={I["capex_q4"]}'}
    for c, w in zip(('E', 'F', 'G', 'H'), ('w1', 'w2', 'w3', 'w4')):
        cells[c] = f'={case_cell}*{I[w]}'
    for c in ('I', 'J', 'K', 'L'):
        cells[c] = f'={case_cell}*(1+{I["g28"]})/4'
    return cells


def year_header(sh, row):
    header(sh, row, ['Line item', None, 'Sep 30, 2026'] + QTRS + [None, 'FY2026E', 'FY2027E', 'FY2028E'])
    put(sh, f'A{row + 1}', 'Fiscal year', NOTE)
    for c in QCOLS:
        put(sh, f'{c}{row + 1}', YEAR_OF[c], NOTE, '0', align='center')
    for c, y in zip(('N', 'O', 'P'), (2026, 2027, 2028)):
        put(sh, f'{c}{row + 1}', y, NOTE, '0', align='center')


def annual(sh, row, yr_row, cols=('O', 'P'), bold=False):
    for c in cols:
        put(sh, f'{c}{row}', f'=SUMIF($D${yr_row}:$L${yr_row},{c}${yr_row},$D{row}:$L{row})', BOLD if bold else BLACK, M)


# ====================================================================== Depreciation
S = 'Depreciation'
title(S, 'Depreciation engine, Q4 2026 to Q4 2028 ($M)',
      'Locked in = assets bought through Sep 30, 2026 (in service or under construction). New spend = CapEx from Q4 2026 on. Assets depreciate from the quarter after they go live.')
put(S, 'A3', '="Selected 2027 CapEx case: "&Inputs!$B$6&" ($"&TEXT(Inputs!$B$17/1000,"0")&"B)"', BOLD)
year_header(S, 5)
YR = 6
section(S, 8, 'Spend')
D = engine(S, 9, capex_formulas(I['c27']), 'selected case')
annual(S, D['capex'], YR, bold=True)
put(S, f'N{D["capex"]}', f'={I["capex9m"]}+D{D["capex"]}', BOLD, M)
section(S, 15, 'A. Locked in: assets bought through Sep 30, 2026')
D.update(run=16, cEs=17, lE=18, cEe=19, cBs=20, lB=21, cBe=22, cumE=23, cumB=24, depCIP=25, lock=26)
labs = {16: 'Run-off of assets in service at Sep 30, 2026', 17: 'Construction in progress, servers and network, start',
        18: 'Goes live, servers and network', 19: 'Construction in progress, servers and network, end',
        20: 'Construction in progress, buildings, start', 21: 'Goes live, buildings', 22: 'Construction in progress, buildings, end',
        23: 'Cumulative gone live, servers and network', 24: 'Cumulative gone live, buildings',
        25: 'Depreciation of construction in progress going live', 26: 'Locked-in depreciation'}
for rr, lab in labs.items():
    put(S, f'A{rr}', lab, BOLD if rr == 26 else BLACK)
put(S, 'B16', 'Python', NOTE)
put(S, 'C19', '=Model_Feed!$C$15', GREEN, M)
put(S, 'C22', '=Model_Feed!$C$16', GREEN, M)
put(S, 'C23', 0, BLUE, M)
put(S, 'C24', 0, BLUE, M)
prev = 'C'
for c in QCOLS:
    put(S, f'{c}16', f'=Model_Feed!{c}$23', GREEN, M)
    put(S, f'{c}17', f'={prev}19', fmt=M)
    put(S, f'{c}18', f'={c}17*{I["pE"]}', fmt=M)
    put(S, f'{c}19', f'={c}17-{c}18', fmt=M)
    put(S, f'{c}20', f'={prev}22', fmt=M)
    put(S, f'{c}21', f'={c}20*{I["pB"]}', fmt=M)
    put(S, f'{c}22', f'={c}20-{c}21', fmt=M)
    put(S, f'{c}23', f'={prev}23+{c}18', fmt=M)
    put(S, f'{c}24', f'={prev}24+{c}21', fmt=M)
    put(S, f'{c}25', f'={prev}23/{I["LE"]}+{prev}24/{I["LB"]}', fmt=M)
    put(S, f'{c}26', f'={c}16+{c}25', BOLD, M)
    ws[S][f'{c}26'].border = TOTAL_BORDER
    prev = c
for rr in (16, 25):
    annual(S, rr, YR)
annual(S, 26, YR, bold=True)
D = new_spend_block(S, 28, D, 'B. New spend: Q4 2026 onward')
annual(S, D['depN'], YR, bold=True)
section(S, 40, 'Total')
put(S, 'A41', 'Total depreciation', BOLD)
put(S, 'A42', 'Locked-in share of depreciation')
put(S, 'A43', 'Growth vs prior year')
put(S, 'A44', 'Construction in progress, end of quarter (model)')
put(S, 'A45', 'Construction in progress, reported (10-Q)')
for c in QCOLS:
    put(S, f'{c}41', f'={c}26+{c}{D["depN"]}', BOLD, M)
    ws[S][f'{c}41'].border = TOTAL_BORDER
    put(S, f'{c}42', f'={c}26/{c}41', fmt=PCT)
    put(S, f'{c}44', f'={c}19+{c}22+{c}{D["cipE_e"]}+{c}{D["cipB_e"]}', fmt=M)
put(S, 'C44', '=C19+C22', fmt=M)
put(S, 'C45', '=Model_Feed!$C$18', GREEN, M)
annual(S, 41, YR, bold=True)
put(S, 'N41', f'={SUM26("E")}+D41', BOLD, M, note='9M 2026 reported (Data_SEC) + Q4 2026 model')
for c in ('O', 'P'):
    put(S, f'{c}42', f'={c}26/{c}41', fmt=PCT)
put(S, 'O43', '=O41/N41-1', fmt=PCT)
put(S, 'P43', '=P41/O41-1', fmt=PCT)
section(S, 47, 'Summary (selected case)')
summ = [('2026E depreciation', '=N41', M), ('2027E depreciation', '=O41', M), ('Growth, 2027E vs 2026E', '=O43', PCT),
        ('2027E locked in by assets bought through Sep 30, 2026', '=O26', M), ('Locked-in share, 2027E', '=O42', PCT),
        ('2027E depreciation from new spend', f'=O{D["depN"]}', M), ('2028E depreciation', '=P41', M),
        ('Locked-in share, 2028E', '=P42', PCT)]
for i, (lab, fml, fm) in enumerate(summ):
    put(S, f'A{48 + i}', lab)
    put(S, f'D{48 + i}', fml, BOLD, fm)
widths(S, {'A': 52, 'B': 7, 'C': 12, **{c: 10.5 for c in QCOLS}, 'M': 2, 'N': 11, 'O': 11, 'P': 11})
ws[S].freeze_panes = 'D7'

# ====================================================================== Margin
S = 'Margin'
title(S, '2027 margin math ($M)', 'FY2026E = 9M reported + a Q4 built from Q4 2025 and the Inputs growth rates. Depreciation from the Depreciation tab.')
header(S, 4, ['Line item', 'FY2025A', 'FY2026E', 'FY2027E', 'Note'])
y25 = AROW[2025]
rows = [
    (5, 'Revenue', f'=Data_SEC!$F${y25}', f'={SUM26("F")}+{Q425("F")}*(1+{I["rq4"]})', f'=C5*(1+{I["r27"]})', '2027E = 2026E x (1 + revenue growth input)', M),
    (6, 'Revenue growth', None, '=C5/B5-1', '=D5/C5-1', '', PCT),
    (7, 'Costs other than depreciation', f'=Data_SEC!$H${y25}', f'={SUM26("H")}+{Q425("H")}*(1+{I["cq4"]})', f'=C7*(1+{I["c27g"]})', 'Revenue less operating income less depreciation', M),
    (8, 'Growth in costs other than depreciation', None, '=C7/B7-1', '=D7/C7-1', '', PCT),
    (9, 'Depreciation', f'=Data_SEC!$E${y25}', '=Depreciation!$N$41', '=Depreciation!$O$41', 'Selected CapEx case', M),
    (10, 'Depreciation growth', None, '=C9/B9-1', '=D9/C9-1', '', PCT),
    (11, 'Operating income', '=B5-B7-B9', '=C5-C7-C9', '=D5-D7-D9', '', M),
    (12, 'Operating margin', '=B11/B5', '=C11/C5', '=D11/D5', '', PCT),
    (13, 'Depreciation, % of revenue', '=B9/B5', '=C9/C5', '=D9/D5', '', PCT),
    (14, 'Costs other than depreciation, % of revenue', '=B7/B5', '=C7/C5', '=D7/D5', '', PCT),
]
for rr, lab, b, c, d, note, fm in rows:
    put(S, f'A{rr}', lab, BOLD if rr in (5, 11, 12) else BLACK)
    for col, v in (('B', b), ('C', c), ('D', d)):
        if v:
            put(S, f'{col}{rr}', v, GREEN if (v.startswith('=Data_SEC') or v.startswith('=Depreciation')) else (BOLD if rr in (11, 12) else BLACK), fm)
    put(S, f'E{rr}', note, NOTE)
section(S, 16, 'Guardrail', 'E')
put(S, 'A17', 'Max 2027 growth in costs other than depreciation to hold the 2026E margin', BOLD)
put(S, 'D17', '=(D5*(1-C12)-D9)/C7-1', BOLD, PCT, fill=PatternFill('solid', fgColor='E6F4EA'))
put(S, 'A18', '2027E margin change vs 2026E at the input cost growth (points)')
put(S, 'D18', '=D12-C12', fmt=SPCT)
put(S, 'A19', 'Extra cost growth allowed per +1 point of 2027 revenue growth (points)')
put(S, 'D19', '=C5*(1-C12)/C7*0.01', fmt='0.00%')
section(S, 21, 'Margin bridge, 2026E to 2027E (points of revenue)', 'E')
bridge = [(22, '2026E operating margin', '=C12'), (23, 'Depreciation, change in share of revenue', '=-(D13-C13)'),
          (24, 'Costs other than depreciation, change in share of revenue', '=-(D14-C14)'), (25, '2027E operating margin', '=D22+D23+D24')]
for rr, lab, fml in bridge:
    put(S, f'A{rr}', lab, BOLD if rr in (22, 25) else BLACK)
    put(S, f'D{rr}', fml, BOLD if rr in (22, 25) else BLACK, PCT if rr in (22, 25) else SPCT)
section(S, 27, 'Sensitivity: 2027E operating margin by revenue growth (rows) and cost growth (columns)', 'G')
put(S, 'A28', 'Revenue growth \\ growth in costs other than depreciation', BOLD)
cost_g = [0.09, 0.115, 0.14, 0.165, 0.19]
rev_g = [0.11, 0.15, 0.19, 0.23, 0.27]
for j, g in enumerate(cost_g):
    put(S, f'{chr(66 + j)}28', g, BLUE, PCT, align='center')
put(S, 'G28', 'Max cost growth to hold 2026E margin', HDR_FONT, fill=HDR_FILL)
for i, g in enumerate(rev_g):
    rr = 29 + i
    put(S, f'A{rr}', g, BLUE, PCT, align='right')
    for j in range(5):
        col = chr(66 + j)
        put(S, f'{col}{rr}', f'=($C$5*(1+$A{rr})-$C$7*(1+{col}$28)-$D$9)/($C$5*(1+$A{rr}))', fmt=PCT, align='center')
    put(S, f'G{rr}', f'=($C$5*(1+$A{rr})*(1-$C$12)-$D$9)/$C$7-1', BOLD, PCT, align='center')
ws[S].conditional_formatting.add('B29:F33', CellIsRule(operator='greaterThanOrEqual', formula=['$C$12'],
                                                       fill=PatternFill('solid', fgColor='E6F4EA')))
ws[S].conditional_formatting.add('B29:F33', CellIsRule(operator='lessThan', formula=['$C$12'],
                                                       fill=PatternFill('solid', fgColor='FCE8E6')))
put(S, 'A35', 'Green = margin at or above 2026E. Depreciation is the selected-case 2027E figure in every cell.', NOTE)
widths(S, {'A': 62, 'B': 12, 'C': 12, 'D': 12, 'E': 12, 'F': 12, 'G': 36})

# ====================================================================== Scenarios
S = 'Scenarios'
title(S, '2027 CapEx scenarios and risks ($M)',
      'Each case runs the same engine as the Depreciation tab. Locked-in depreciation is identical across cases, so 2027 CapEx mostly moves 2028.')
header(S, 4, ['Case', '2027 CapEx', '2027E depreciation', '2028E depreciation', 'Locked-in share, 2027E', '2027E vs Base', '2028E vs Base'])
year_header(S, 22)
SYR = 23
blocks = {}
r0 = 25
for k, (case, key) in enumerate((('Low', 'c27_lo'), ('Base', 'c27_base'), ('High', 'c27_hi'))):
    section(S, r0, f'Case: {case}')
    R = engine(S, r0 + 1, capex_formulas(I[key]), f'{case} case')
    R = new_spend_block(S, r0 + 6, R, f'{case}: new spend')
    R['lock'] = R['depN'] + 1
    R['tot'] = R['depN'] + 2
    put(S, f'A{R["lock"]}', 'Locked-in depreciation (same in every case)')
    put(S, f'A{R["tot"]}', f'Total depreciation, {case} case', BOLD)
    for c in QCOLS:
        put(S, f'{c}{R["lock"]}', f'=Depreciation!{c}$26', GREEN, M)
        put(S, f'{c}{R["tot"]}', f'={c}{R["lock"]}+{c}{R["depN"]}', BOLD, M)
        ws[S][f'{c}{R["tot"]}'].border = TOTAL_BORDER
    annual(S, R['tot'], SYR, bold=True)
    annual(S, R['lock'], SYR)
    blocks[case] = R
    put(S, f'A{5 + k}', case, BOLD)
    put(S, f'B{5 + k}', f'={I[key]}', GREEN, M)
    put(S, f'C{5 + k}', f'=O{R["tot"]}', BOLD, M)
    put(S, f'D{5 + k}', f'=P{R["tot"]}', BOLD, M)
    put(S, f'E{5 + k}', f'=O{R["lock"]}/O{R["tot"]}', fmt=PCT)
    r0 = R['tot'] + 2
for k in range(3):
    put(S, f'F{5 + k}', f'=C{5 + k}-$C$6', fmt=M)
    put(S, f'G{5 + k}', f'=D{5 + k}-$D$6', fmt=M)
section(S, 9, 'Accounting and mix risks (Python vintage engine; needs per-vintage book values)', 'G')
header(S, 10, ['Risk', '2027E impact', '2028E impact', 'Note'])
risks = [(11, 'Servers and network life cut from 6 to 5 years, Jan 2027', f'={REF["life27"]}', f'={REF["life28"]}',
          'Amazon cut a subset of servers to 5 years in Jan 2025, citing AI pace'),
         (12, 'Servers take 60% of 2026+ spend (base 65%)', f'={REF["mix60"]}-{REF["dep27"]}', None, 'Shorter-lived mix lowers 2027E less than it lowers 2028E'),
         (13, 'Servers take 70% of 2026+ spend (base 65%)', f'={REF["mix70"]}-{REF["dep27"]}', None, '')]
for rr, lab, v27, v28, note in risks:
    put(S, f'A{rr}', lab)
    put(S, f'B{rr}', v27, GREEN, '+#,##0;-#,##0;"-"')
    if v28:
        put(S, f'C{rr}', v28, GREEN, '+#,##0;-#,##0;"-"')
    put(S, f'D{rr}', note, NOTE)
put(S, 'A14', '="Life cut as a share of 2027E revenue (points): "&TEXT(B11/Margin!$D$5,"0.0%")', NOTE)
widths(S, {'A': 52, 'B': 13, 'C': 14, **{c: 11 for c in QCOLS}, 'M': 2, 'N': 11, 'O': 11, 'P': 11})
ws[S].column_dimensions['D'].width = 14
ws[S].column_dimensions['E'].width = 14
ws[S].column_dimensions['F'].width = 13
ws[S].column_dimensions['G'].width = 13
ws[S].freeze_panes = 'B5'

# ====================================================================== Backtest
S = 'Backtest'
title(S, 'Out-of-sample backtest: quarterly depreciation ($M)',
      'Parameters fit on data through Dec 2024 only (2026 spend mix carried forward from 2024-2025), then run on reported CapEx to forecast Q1 2025 to Q3 2026.')
header(S, 4, ['Quarter', 'Model forecast', 'Reported', 'Error', 'Absolute error'])
bt = RES['backtest']['quarters']
for i, b in enumerate(bt):
    rr = 5 + i
    put(S, f'A{rr}', b['quarter'])
    put(S, f'B{rr}', b['model'], BLUE, M)
    put(S, f'C{rr}', f'=Data_SEC!$E${DROW[b["quarter"]]}', GREEN, M)
    put(S, f'D{rr}', f'=B{rr}/C{rr}-1', fmt=SPCT)
    put(S, f'E{rr}', f'=ABS(D{rr})', fmt=PCT)
last = 4 + len(bt)
put(S, f'A{last + 1}', 'Mean absolute error', BOLD)
put(S, f'E{last + 1}', f'=AVERAGE(E5:E{last})', BOLD, PCT)
put(S, f'A{last + 2}', 'Largest overestimate / underestimate')
put(S, f'D{last + 2}', f'=MAX(D5:D{last})', fmt=SPCT)
put(S, f'E{last + 2}', f'=MIN(D5:D{last})', fmt=SPCT)
put(S, f'A{last + 4}', 'FY2025')
put(S, f'B{last + 4}', '=SUM(B5:B8)', fmt=M)
put(S, f'C{last + 4}', '=SUM(C5:C8)', fmt=M)
put(S, f'D{last + 4}', f'=B{last + 4}/C{last + 4}-1', fmt=SPCT)
put(S, f'A{last + 5}', '9M 2026')
put(S, f'B{last + 5}', f'=SUM(B9:B{last})', fmt=M)
put(S, f'C{last + 5}', f'=SUM(C9:C{last})', fmt=M)
put(S, f'D{last + 5}', f'=B{last + 5}/C{last + 5}-1', fmt=SPCT)
cip = RES['backtest']['cip']
put(S, f'A{last + 6}', 'Construction in progress, Dec 31, 2025')
put(S, f'B{last + 6}', cip['2025Q4']['model'], BLUE, M)
put(S, f'C{last + 6}', 78592, BLUE, M, note=f'Alphabet 10-K FY2025: {SRC_10K}')
put(S, f'D{last + 6}', f'=B{last + 6}/C{last + 6}-1', fmt=SPCT)
put(S, f'A{last + 7}', 'Construction in progress, Sep 30, 2026')
put(S, f'B{last + 7}', cip['2026Q3']['model'], BLUE, M)
put(S, f'C{last + 7}', '=Model_Feed!$C$18', GREEN, M)
put(S, f'D{last + 7}', f'=B{last + 7}/C{last + 7}-1', fmt=SPCT)
section(S, last + 9, 'Parameters used (fit through Dec 2024)', 'E')
po = RES['params_out_of_sample']
for i, (k, lab) in enumerate(plabels):
    put(S, f'A{last + 10 + i}', lab)
    put(S, f'B{last + 10 + i}', po[k], BLUE, '0' if k == 'LB' else '0%')
put(S, f'A{last + 19}', 'Misses widen in 2026 as spend tilted to servers, which depreciate faster; the full fit picks this up.', NOTE)
ch = LineChart()
ch.title = 'Depreciation: model forecast vs reported ($M)'
ch.height, ch.width = 7.5, 16
ch.add_data(Reference(ws[S], min_col=2, max_col=3, min_row=4, max_row=last), titles_from_data=True)
ch.set_categories(Reference(ws[S], min_col=1, min_row=5, max_row=last))
ch.y_axis.title = '$M'
ch.y_axis.numFmt = '#,##0'
ws[S].add_chart(ch, 'G4')
widths(S, {'A': 46, 'B': 15, 'C': 13, 'D': 11, 'E': 15})

# ====================================================================== Checks
S = 'Checks'
title(S, 'Model checks', 'Every row should read OK. ERROR means a formula or an input broke the model.')
header(S, 4, ['#', 'Check', 'Value', 'Target', 'Difference', 'Status'])
yrs = [2023, 2024, 2025]
sum_q = lambda col: '+'.join(f'ABS(SUMIFS({QR(col)},{QR("B")},{y})-Data_SEC!${col}${AROW[y]})' for y in yrs)
defaults = (f'AND({I["case"]}=2,{I["g26_mid"]}=200000,{I["c27_base"]}=300000,{I["g28"]}=0.1,{I["e"]}={P["e4"]},'
            f'{I["o"]}={FEED["other_share"]},{I["land"]}={FEED["land_share"]},{I["pE"]}={P["pE"]},{I["pB"]}={P["pB"]},'
            f'{I["LE"]}=24,{I["LB"]}={FEED["life_build_q"]},{I["LO"]}=28,{I["w1"]}=0.22,{I["w2"]}=0.24,{I["w3"]}=0.26,{I["w4"]}=0.28)')
checks = [
    ('Quarterly depreciation 2023-2025 sums to full-year XBRL', f'={sum_q("E")}', 0, 0.5),
    ('Quarterly CapEx 2023-2025 sums to full-year XBRL', f'={sum_q("D")}', 0, 0.5),
    ('Quarterly revenue 2023-2025 sums to full-year XBRL', f'={sum_q("F")}', 0, 0.5),
    ('Quarterly operating income 2023-2025 sums to full-year XBRL', f'={sum_q("G")}', 0, 0.5),
    ('9M 2026 CapEx ties to 10-Q', f'={SUM26("D")}', f'={CTRL["capex"]}', 0.5),
    ('9M 2026 depreciation ties to 10-Q', f'={SUM26("E")}', f'={CTRL["dep"]}', 0.5),
    ('9M 2026 revenue ties to 10-Q', f'={SUM26("F")}', f'={CTRL["rev"]}', 0.5),
    ('9M 2026 operating income ties to 10-Q', f'={SUM26("G")}', f'={CTRL["oi"]}', 0.5),
    ('FY2025 operating income rebuilt in Margin tab ties to reported', '=Margin!$B$11', f'=Data_SEC!$G${y25}', 0.5),
    ('2027 CapEx phasing sums to 100%', f'={I["w_sum"]}', 1, 0.0001),
    ('Asset shares leave a non-negative buildings share', f'=MIN(0,{I["b"]})', 0, 0.0001),
    ('Locked in + new spend = total depreciation, 2027E', f'=Depreciation!$O$26+Depreciation!$O${D["depN"]}', '=Depreciation!$O$41', 0.5),
    ('Scenarios tab, selected case = Depreciation tab, 2027E', '=CHOOSE(Inputs!$B$5,Scenarios!$C$5,Scenarios!$C$6,Scenarios!$C$7)', '=Depreciation!$O$41', 0.5),
    ('Margin bridge ends at the 2027E margin', '=Margin!$D$25', '=Margin!$D$12', 0.00001),
]
for i, (lab, val, tgt, tol) in enumerate(checks):
    rr = 5 + i
    put(S, f'A{rr}', i + 1, fmt='0')
    put(S, f'B{rr}', lab)
    put(S, f'C{rr}', val, fmt=M if tol >= 0.5 else '0.0000')
    put(S, f'D{rr}', tgt, BLUE if not isinstance(tgt, str) else GREEN, M if tol >= 0.5 else '0.0000')
    put(S, f'E{rr}', f'=C{rr}-D{rr}', fmt=M1 if tol >= 0.5 else '0.0000')
    put(S, f'F{rr}', f'=IF(ABS(E{rr})<={tol},"OK","ERROR")', BOLD)
rr = 5 + len(checks)
put(S, f'A{rr}', len(checks) + 1, fmt='0')
put(S, f'B{rr}', 'Excel 2027E equals the Python model at default inputs (within $1M)')
put(S, f'C{rr}', '=Depreciation!$O$41', fmt=M)
put(S, f'D{rr}', f'={REF["dep27"]}', GREEN, M)
put(S, f'E{rr}', f'=C{rr}-D{rr}', fmt=M1)
put(S, f'F{rr}', f'=IF({defaults},IF(ABS(E{rr})<=1,"OK","ERROR"),"n/a: inputs changed")', BOLD)
LAST_CHECK = rr
put(S, 'B3', f'=IF(COUNTIF(F5:F{LAST_CHECK},"ERROR")=0,"ALL CHECKS OK","CHECK ERRORS: see column F")', BOLD_GREEN)
widths(S, {'A': 5, 'B': 66, 'C': 13, 'D': 13, 'E': 12, 'F': 22})

# ====================================================================== Cover
S = 'Cover'
put(S, 'A1', 'Alphabet 2027 Depreciation and Margin Model', Font(name=F, size=18, bold=True, color='1A73E8'))
for col, hexc in zip('ABCD', ('4285F4', 'EA4335', 'FBBC04', '34A853')):   # Google colour band
    ws[S][f'{col}3'].fill = PatternFill('solid', fgColor=hexc)
ws[S].row_dimensions[3].height = 5
put(S, 'A2', 'Portfolio project by Nhi Nguyen. Public SEC data only; not affiliated with Alphabet. $ in millions unless noted. Figures marked E are estimates.', NOTE)
put(S, 'A4', 'How much will Alphabet\'s AI build-out raise 2027 depreciation, how much of it is already locked in, and what cost growth holds the operating margin?', BOLD)
section(S, 6, 'Key outputs (selected case)', 'C')
kout = [('2027 CapEx case', '=Inputs!$B$6', None), ('2027E depreciation', '=Depreciation!$O$41', M),
        ('Growth vs 2026E', '=Depreciation!$O$43', PCT), ('Locked in by assets bought through Sep 30, 2026', '=Depreciation!$O$42', PCT),
        ('2027E depreciation, % of revenue', '=Margin!$D$13', PCT),
        ('Max 2027 growth in other costs to hold the 2026E margin', '=Margin!$D$17', PCT),
        ('2027E operating margin at the input cost growth', '=Margin!$D$12', PCT), ('Model checks', '=Checks!$B$3', None)]
for i, (lab, fml, fm) in enumerate(kout):
    put(S, f'A{7 + i}', lab)
    put(S, f'B{7 + i}', fml, BOLD_GREEN, fm)
section(S, 16, 'How to use', 'C')
steps = ['1. Pick the 2027 CapEx case on Inputs (cell B5): 1 = Low, 2 = Base, 3 = High.',
         '2. Flex any blue input on Inputs: mix, go-live rates, useful lives, revenue and cost growth.',
         '3. Read Depreciation (quarterly engine), Margin (guardrail and sensitivity) and Scenarios; confirm Checks reads ALL CHECKS OK.']
for i, s_ in enumerate(steps):
    put(S, f'A{17 + i}', s_)
section(S, 21, 'Colour code', 'C')
legend = [('Blue text', 'Hard-coded input or reported data', BLUE, None), ('Black text', 'Formula', BLACK, None),
          ('Green text', 'Link to another tab', GREEN, None), ('Yellow fill', 'Scenario lever', BLUE, YELLOW)]
for i, (a, b, fnt, fill) in enumerate(legend):
    put(S, f'A{22 + i}', a, fnt, fill=fill)
    put(S, f'B{22 + i}', b)
section(S, 27, 'Tabs', 'C')
tabs = [('Inputs', 'Every assumption, with its source'), ('Depreciation', 'Quarterly engine: locked-in run-off + construction going live + new spend'),
        ('Margin', '2025A to 2027E P&L, guardrail, margin bridge, sensitivity grid'), ('Scenarios', 'Low / Base / High 2027 CapEx and accounting risks'),
        ('Backtest', 'Out-of-sample test of the depreciation model, Q1 2025 to Q3 2026'), ('Data_SEC', 'Reported quarters and years from the SQL pipeline, with 10-Q control totals'),
        ('Model_Feed', 'Python vintage engine outputs the workbook builds on'), ('Checks', '15 automated checks')]
for i, (a, b) in enumerate(tabs):
    put(S, f'A{28 + i}', a, BOLD)
    put(S, f'B{28 + i}', b)
section(S, 37, 'Method and sources', 'C')
src = ['Python vintage engine (model/depreciation_model.py) calibrates the asset base on SEC data from 2007 to Q3 2026; this workbook rebuilds the forecast from Sep 30, 2026 with live formulas.',
       f'Alphabet 10-Q, Q3 2026: {SRC_10Q}', f'Alphabet 10-K, FY2025: {SRC_10K}', f'Q3 2026 earnings call transcript: {SRC_CALL}',
       f'SEC XBRL API: {SRC_API}<tag>.json (CapEx, depreciation, revenue, operating income)']
for i, s_ in enumerate(src):
    put(S, f'A{38 + i}', s_, NOTE if i else BLACK)
widths(S, {'A': 52, 'B': 16, 'C': 60, 'D': 24})

for sh in ws.values():
    sh.page_setup.orientation = 'landscape'
    sh.page_setup.fitToWidth = 1
    sh.page_setup.fitToHeight = 0
    sh.sheet_properties.pageSetUpPr.fitToPage = True
wb.active = 0
wb.save(OUT)
print('wrote', OUT)
