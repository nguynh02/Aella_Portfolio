-- 04_tieout_checks.sql
-- Automated checks before any number reaches the model. PASS / WARN / INFO / FAIL per row.
-- Tolerance: the larger of $2M or 0.25% (XBRL values are rounded to $1M).

CREATE OR REPLACE TABLE finance.tieout_report AS
WITH
derived_vs_reported AS (
  -- 1. Quarter derived from YTD facts vs the 3-month figure reported for the same quarter
  SELECT
    'derived_vs_reported_quarter' AS check_name,
    d.concept,
    CONCAT(CAST(d.fiscal_year AS STRING), 'Q', CAST(d.fiscal_quarter AS STRING)) AS period,
    r.value_musd AS expected_musd,
    d.value_musd AS actual_musd
  FROM finance.quarterly_facts AS d
  JOIN finance.clean_facts AS r
    ON r.concept = d.concept
   AND r.period_end = d.period_end
   AND r.basis = 'discrete'
   AND r.months = 3
),
annual_ranked AS (
  SELECT
    concept,
    fiscal_year,
    value_musd,
    ROW_NUMBER() OVER (PARTITION BY concept, period_start, period_end ORDER BY filed ASC) AS first_rank,
    ROW_NUMBER() OVER (PARTITION BY concept, period_start, period_end ORDER BY filed DESC) AS last_rank
  FROM finance.mapped_facts
  WHERE concept IS NOT NULL AND months = 12
),
restatements AS (
  -- 2. First-reported vs latest-filed full-year value (restatements and reclassifications)
  SELECT
    'annual_restatement' AS check_name,
    f.concept,
    CAST(f.fiscal_year AS STRING) AS period,
    f.value_musd AS expected_musd,
    l.value_musd AS actual_musd
  FROM annual_ranked AS f
  JOIN annual_ranked AS l
    ON l.concept = f.concept AND l.fiscal_year = f.fiscal_year AND l.last_rank = 1
  WHERE f.first_rank = 1
),
years AS (
  SELECT DISTINCT fiscal_year FROM finance.model_inputs_quarterly
),
quarters AS (
  SELECT 1 AS fiscal_quarter UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4
),
coverage_spec AS (
  SELECT 'capex' AS concept, 2015 AS first_year UNION ALL
  SELECT 'depreciation', 2023 UNION ALL
  SELECT 'revenue', 2021 UNION ALL
  SELECT 'operating_income', 2019
),
expected AS (
  SELECT s.concept, y.fiscal_year, q.fiscal_quarter
  FROM coverage_spec AS s
  CROSS JOIN years AS y
  CROSS JOIN quarters AS q
  WHERE y.fiscal_year >= s.first_year
    AND y.fiscal_year * 10 + q.fiscal_quarter <= 20263   -- latest reported quarter: Q3 2026
),
present AS (
  SELECT 'capex' AS concept, fiscal_year, fiscal_quarter FROM finance.model_inputs_quarterly WHERE capex_musd IS NOT NULL
  UNION ALL SELECT 'depreciation', fiscal_year, fiscal_quarter FROM finance.model_inputs_quarterly WHERE depreciation_musd IS NOT NULL
  UNION ALL SELECT 'revenue', fiscal_year, fiscal_quarter FROM finance.model_inputs_quarterly WHERE revenue_musd IS NOT NULL
  UNION ALL SELECT 'operating_income', fiscal_year, fiscal_quarter FROM finance.model_inputs_quarterly WHERE operating_income_musd IS NOT NULL
),
completeness AS (
  -- 3. Every quarter the model needs is present
  SELECT
    'quarter_completeness' AS check_name,
    e.concept,
    STRING_AGG(CASE WHEN p.concept IS NULL THEN CONCAT(CAST(e.fiscal_year AS STRING), 'Q', CAST(e.fiscal_quarter AS STRING)) END, ', ') AS missing,
    COUNT(*) AS n_expected,
    COUNT(p.concept) AS n_present
  FROM expected AS e
  LEFT JOIN present AS p
    ON p.concept = e.concept AND p.fiscal_year = e.fiscal_year AND p.fiscal_quarter = e.fiscal_quarter
  GROUP BY e.concept
),
controls AS (
  -- 4. Pipeline 9M 2026 totals vs control totals hand-keyed from the Q3 2026 10-Q
  SELECT
    'control_total_9m2026' AS check_name,
    CASE m.item
      WHEN 'control_capex_ytd' THEN 'capex'
      WHEN 'control_depreciation_ytd' THEN 'depreciation'
      WHEN 'control_revenue_ytd' THEN 'revenue'
      WHEN 'operating_income_ytd' THEN 'operating_income'
    END AS concept,
    '9M2026' AS period,
    m.value_musd AS expected_musd
  FROM finance.manual_inputs AS m
  WHERE m.period_or_date = '9M2026'
    AND m.item IN ('control_capex_ytd', 'control_depreciation_ytd', 'control_revenue_ytd', 'operating_income_ytd')
),
pipeline_9m AS (
  SELECT 'capex' AS concept, SUM(capex_musd) AS actual_musd FROM finance.model_inputs_quarterly WHERE fiscal_year = 2026
  UNION ALL SELECT 'depreciation', SUM(depreciation_musd) FROM finance.model_inputs_quarterly WHERE fiscal_year = 2026
  UNION ALL SELECT 'revenue', SUM(revenue_musd) FROM finance.model_inputs_quarterly WHERE fiscal_year = 2026
  UNION ALL SELECT 'operating_income', SUM(operating_income_musd) FROM finance.model_inputs_quarterly WHERE fiscal_year = 2026
),
negatives AS (
  -- 5. No negative quarters for flows that cannot be negative
  SELECT
    'non_negative_quarter' AS check_name,
    concept,
    CONCAT(CAST(fiscal_year AS STRING), 'Q', CAST(fiscal_quarter AS STRING)) AS period,
    0.0 AS expected_musd,
    value_musd AS actual_musd
  FROM finance.quarterly_facts
  WHERE concept IN ('capex', 'depreciation', 'revenue') AND value_musd < 0
)
SELECT
  check_name, concept, period, expected_musd, actual_musd,
  actual_musd - expected_musd AS diff_musd,
  CASE WHEN ABS(actual_musd - expected_musd) <= GREATEST(2, 0.0025 * ABS(expected_musd)) THEN 'PASS' ELSE 'WARN' END AS status,
  'Derived quarter vs reported 3-month figure (latest filing)' AS note
FROM derived_vs_reported
UNION ALL
SELECT
  check_name, concept, period, expected_musd, actual_musd,
  actual_musd - expected_musd,
  CASE WHEN ABS(actual_musd - expected_musd) <= GREATEST(2, 0.0025 * ABS(expected_musd)) THEN 'PASS' ELSE 'INFO' END,
  'First-reported vs latest-filed full year; the latest value is used'
FROM restatements
UNION ALL
SELECT
  check_name, concept, 'all quarters', n_expected, n_present,
  n_present - n_expected,
  CASE WHEN n_present = n_expected THEN 'PASS' ELSE 'FAIL' END,
  CASE WHEN missing IS NULL THEN 'Every expected quarter present' ELSE CONCAT('Missing: ', missing) END
FROM completeness
UNION ALL
SELECT
  c.check_name, c.concept, c.period, c.expected_musd, p.actual_musd,
  p.actual_musd - c.expected_musd,
  CASE WHEN ABS(p.actual_musd - c.expected_musd) <= 2 THEN 'PASS' ELSE 'FAIL' END,
  'Sum of Q1-Q3 2026 vs 10-Q control total'
FROM controls AS c
JOIN pipeline_9m AS p ON p.concept = c.concept
UNION ALL
SELECT
  check_name, concept, period, expected_musd, actual_musd,
  actual_musd - expected_musd, 'FAIL', 'Negative quarter after YTD differencing'
FROM negatives;
