-- 01_clean_facts.sql
-- Map SEC XBRL tags to model concepts, classify each fact's period, keep the latest filing per period.
-- Dialect: BigQuery Standard SQL (also runs unchanged on DuckDB for local tests).
-- Note: in the SEC API, fy/fp describe the FILING, not the fact. Periods come from the dates only.

CREATE OR REPLACE TABLE finance.mapped_facts AS
SELECT
  CASE tag
    WHEN 'PaymentsToAcquirePropertyPlantAndEquipment' THEN 'capex'
    WHEN 'Depreciation' THEN 'depreciation'
    WHEN 'Revenues' THEN 'revenue'
    -- Alphabet tagged revenue with this element in 2021-2025 filings, so both tags map to one concept
    WHEN 'RevenueFromContractWithCustomerExcludingAssessedTax' THEN 'revenue'
    WHEN 'OperatingIncomeLoss' THEN 'operating_income'
  END AS concept,
  tag,
  cik,
  period_start,
  period_end,
  (EXTRACT(YEAR FROM period_end) * 12 + EXTRACT(MONTH FROM period_end))
    - (EXTRACT(YEAR FROM period_start) * 12 + EXTRACT(MONTH FROM period_start)) + 1 AS months,
  EXTRACT(YEAR FROM period_end) AS fiscal_year,
  value_usd / 1e6 AS value_musd,
  form,
  filed
FROM finance.raw_xbrl_facts;

CREATE OR REPLACE TABLE finance.clean_facts AS
SELECT
  concept,
  period_start,
  period_end,
  months,
  fiscal_year,
  value_musd,
  CASE
    WHEN EXTRACT(MONTH FROM period_start) = 1 AND EXTRACT(DAY FROM period_start) = 1 THEN 'ytd'
    ELSE 'discrete'
  END AS basis,
  tag,
  cik,
  form,
  filed
FROM finance.mapped_facts
WHERE concept IS NOT NULL
  AND months IN (3, 6, 9, 12)
-- latest filing wins, so restated comparatives replace first-reported values
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY concept, period_start, period_end
  ORDER BY filed DESC, tag
) = 1;
