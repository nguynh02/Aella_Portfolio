-- 05_peer_capex.sql
-- Hyperscaler CapEx tracker: Alphabet, Microsoft, Amazon, Meta, Oracle on one quarterly table.
-- Handles different fiscal years (Microsoft starts July 1, Oracle June 1) and Amazon's trailing-12-month facts.
-- Dialect: BigQuery Standard SQL (runs unchanged on DuckDB).

CREATE OR REPLACE TABLE finance.peer_capex_quarterly AS
WITH all_facts AS (
  SELECT cik, period_start, period_end, value_usd, form, filed
  FROM finance.raw_peer_facts
  UNION ALL
  SELECT cik, period_start, period_end, value_usd, form, filed
  FROM finance.raw_xbrl_facts
  WHERE cik = 1652044 AND tag = 'PaymentsToAcquirePropertyPlantAndEquipment'
    AND period_end >= DATE '2023-01-01'
),
latest AS (
  SELECT
    cik, period_start, period_end, value_usd / 1e6 AS value_musd, form,
    (EXTRACT(YEAR FROM period_end) * 12 + EXTRACT(MONTH FROM period_end))
      - (EXTRACT(YEAR FROM period_start) * 12 + EXTRACT(MONTH FROM period_start)) + 1 AS months
  FROM all_facts
  WHERE form IN ('10-K', '10-Q')
  QUALIFY ROW_NUMBER() OVER (PARTITION BY cik, period_start, period_end ORDER BY filed DESC) = 1
),
fiscal_start AS (
  -- the month each company's fiscal year starts, read from its 10-K full-year facts
  SELECT cik, MIN(EXTRACT(MONTH FROM period_start)) AS fy_start_month
  FROM latest
  WHERE form = '10-K' AND months = 12
  GROUP BY cik
),
ytd AS (
  -- year-to-date facts only: they start on the first day of the fiscal year (drops trailing-12-month facts)
  SELECT
    l.cik, l.period_start, l.period_end, l.months, l.value_musd,
    LAG(l.months) OVER w AS prev_months,
    LAG(l.value_musd) OVER w AS prev_value
  FROM latest AS l
  JOIN fiscal_start AS f ON f.cik = l.cik
  WHERE EXTRACT(MONTH FROM l.period_start) = f.fy_start_month
    AND l.months IN (3, 6, 9, 12)
  WINDOW w AS (PARTITION BY l.cik, l.period_start ORDER BY l.months)
),
quarters AS (
  SELECT
    cik, period_end,
    CASE WHEN months = 3 THEN value_musd ELSE value_musd - prev_value END AS capex_musd
  FROM ytd
  WHERE months = 3 OR prev_months = months - 3
),
labelled AS (
  SELECT
    cik,
    CASE cik
      WHEN 1652044 THEN 'Alphabet'
      WHEN 789019 THEN 'Microsoft'
      WHEN 1018724 THEN 'Amazon'
      WHEN 1326801 THEN 'Meta'
      WHEN 1341439 THEN 'Oracle'
    END AS company,
    period_end,
    -- calendar quarter the fiscal quarter mostly falls in (Oracle's Jun-Aug quarter maps to Q3)
    EXTRACT(YEAR FROM period_end) AS cal_year,
    CASE WHEN EXTRACT(MONTH FROM period_end) <= 3 THEN 1
         WHEN EXTRACT(MONTH FROM period_end) <= 6 THEN 2
         WHEN EXTRACT(MONTH FROM period_end) <= 9 THEN 3 ELSE 4 END AS cal_quarter,
    capex_musd
  FROM quarters
)
SELECT
  company,
  cik,
  period_end,
  cal_year,
  cal_quarter,
  CONCAT(CAST(cal_year AS STRING), 'Q', CAST(cal_quarter AS STRING)) AS quarter_label,
  capex_musd,
  CASE WHEN COUNT(*) OVER w4 = 4 THEN SUM(capex_musd) OVER w4 END AS capex_ttm_musd,
  capex_musd / NULLIF(LAG(capex_musd, 4) OVER wq, 0) - 1 AS capex_yoy
FROM labelled
WINDOW
  wq AS (PARTITION BY cik ORDER BY period_end),
  w4 AS (PARTITION BY cik ORDER BY period_end ROWS BETWEEN 3 PRECEDING AND CURRENT ROW);

-- Tie-out: quarters derived from year-to-date facts vs the 3-month figures companies also report
CREATE OR REPLACE TABLE finance.peer_tieout AS
WITH reported AS (
  SELECT
    cik, period_end, value_usd / 1e6 AS reported_musd
  FROM finance.raw_peer_facts
  WHERE form IN ('10-K', '10-Q')
    AND (EXTRACT(YEAR FROM period_end) * 12 + EXTRACT(MONTH FROM period_end))
      - (EXTRACT(YEAR FROM period_start) * 12 + EXTRACT(MONTH FROM period_start)) + 1 = 3
  QUALIFY ROW_NUMBER() OVER (PARTITION BY cik, period_start, period_end ORDER BY filed DESC) = 1
)
SELECT
  q.company, q.quarter_label, r.reported_musd, q.capex_musd AS derived_musd,
  q.capex_musd - r.reported_musd AS diff_musd,
  CASE WHEN ABS(q.capex_musd - r.reported_musd) <= 2 THEN 'PASS' ELSE 'FAIL' END AS status
FROM finance.peer_capex_quarterly AS q
JOIN reported AS r ON r.cik = q.cik AND r.period_end = q.period_end;
