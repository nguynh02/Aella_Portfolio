-- 02_quarterly_facts.sql
-- Companies report cash flow items year to date. Turn YTD facts into discrete quarters:
-- Q1 = 3M, Q2 = 6M less 3M, Q3 = 9M less 6M, Q4 = 12M less 9M.
-- A quarter is derived only when the prior YTD fact exists (no silent gaps).

CREATE OR REPLACE TABLE finance.quarterly_facts AS
WITH ytd AS (
  SELECT
    concept,
    fiscal_year,
    months,
    period_end,
    value_musd,
    filed,
    LAG(months) OVER w AS prev_months,
    LAG(value_musd) OVER w AS prev_value
  FROM finance.clean_facts
  WHERE basis = 'ytd'
  WINDOW w AS (PARTITION BY concept, fiscal_year ORDER BY months)
)
SELECT
  concept,
  fiscal_year,
  CASE months WHEN 3 THEN 1 WHEN 6 THEN 2 WHEN 9 THEN 3 WHEN 12 THEN 4 END AS fiscal_quarter,
  period_end,
  CASE WHEN months = 3 THEN value_musd ELSE value_musd - prev_value END AS value_musd,
  CASE WHEN months = 3 THEN 'reported_q1' ELSE 'derived_from_ytd' END AS method,
  filed
FROM ytd
WHERE months = 3
   OR prev_months = months - 3;
