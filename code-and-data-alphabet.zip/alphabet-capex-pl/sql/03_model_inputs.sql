-- 03_model_inputs.sql
-- Wide tables the depreciation model and the Excel file read.

CREATE OR REPLACE TABLE finance.model_inputs_quarterly AS
WITH q AS (
  SELECT concept, fiscal_year, fiscal_quarter, value_musd, method
  FROM finance.quarterly_facts
  UNION ALL
  -- Q3 2026 operating income: hand-keyed 9M total from the 10-Q less the XBRL H1 total,
  -- used only while the SEC API has no Q3 2026 OperatingIncomeLoss fact
  SELECT 'operating_income', 2026, 3, m.value_musd - h1.value_musd, 'manual_10q'
  FROM finance.manual_inputs AS m
  JOIN finance.clean_facts AS h1
    ON h1.concept = 'operating_income'
   AND h1.period_end = DATE '2026-06-30'
   AND h1.months = 6
  WHERE m.item = 'operating_income_ytd'
    AND m.period_or_date = '9M2026'
    AND NOT EXISTS (
      SELECT 1 FROM finance.quarterly_facts AS x
      WHERE x.concept = 'operating_income' AND x.fiscal_year = 2026 AND x.fiscal_quarter = 3
    )
)
SELECT
  fiscal_year,
  fiscal_quarter,
  CONCAT(CAST(fiscal_year AS STRING), 'Q', CAST(fiscal_quarter AS STRING)) AS quarter_label,
  SUM(CASE WHEN concept = 'capex' THEN value_musd END) AS capex_musd,
  SUM(CASE WHEN concept = 'depreciation' THEN value_musd END) AS depreciation_musd,
  SUM(CASE WHEN concept = 'revenue' THEN value_musd END) AS revenue_musd,
  SUM(CASE WHEN concept = 'operating_income' THEN value_musd END) AS operating_income_musd,
  STRING_AGG(DISTINCT CASE WHEN method = 'manual_10q' THEN CONCAT(concept, ' hand-keyed from 10-Q') END, '; ') AS flags
FROM q
WHERE fiscal_year >= 2015
GROUP BY fiscal_year, fiscal_quarter;

CREATE OR REPLACE TABLE finance.model_inputs_annual AS
WITH a AS (
  SELECT
    fiscal_year,
    SUM(CASE WHEN concept = 'capex' THEN value_musd END) AS capex_musd,
    SUM(CASE WHEN concept = 'depreciation' THEN value_musd END) AS depreciation_musd,
    SUM(CASE WHEN concept = 'revenue' THEN value_musd END) AS revenue_musd,
    SUM(CASE WHEN concept = 'operating_income' THEN value_musd END) AS operating_income_musd
  FROM finance.clean_facts
  WHERE months = 12
  GROUP BY fiscal_year
)
SELECT
  fiscal_year,
  capex_musd,
  depreciation_musd,
  revenue_musd,
  operating_income_musd,
  ROUND(capex_musd / NULLIF(depreciation_musd, 0), 2) AS capex_to_depreciation,
  ROUND(depreciation_musd / NULLIF(revenue_musd, 0), 4) AS depreciation_pct_revenue,
  ROUND(operating_income_musd / NULLIF(revenue_musd, 0), 4) AS operating_margin
FROM a;
