# Alphabet AI CapEx-to-P&L Planning Model

Independent FP&A case study on public SEC data. Not affiliated with Alphabet. E = estimate.

**Question:** Alphabet will spend about $200B on property and equipment in 2026, mostly AI servers and data centers. How much will that raise 2027 depreciation, how much of it is already locked in, and how fast can other costs grow if the operating margin is to hold?

## Answer (data as of Nov 8, 2026)

| Metric | Result |
| --- | --- |
| 2027E depreciation | $53.1B, +69% vs $31.4B in 2026E |
| Locked in by assets bought through Sep 30, 2026 | $43.9B (83%): $36.6B in-service run-off + $7.3B construction in progress going live |
| Depreciation, % of revenue | 5.2% (2025), 6.3% (2026E), 9.0% (2027E at +19% revenue) |
| Max 2027 growth in non-depreciation costs to hold the 33.1% 2026E margin | 13.7% (2026E pace: 18.9%) |
| 2027 CapEx $250B / $300B / $350B | 2027E depreciation $52.3B / $53.1B / $54.0B; 2028E $79.6B / $84.6B / $89.6B |
| Server and network life cut from 6 to 5 years (Jan 2027) | +$13.7B 2027E depreciation |
| Out-of-sample backtest (fit through Dec 2024; Q1 2025 to Q3 2026) | 2.8% mean absolute error per quarter; FY2025 within 1.3% |

![83% of projected 2027 depreciation is already locked in](docs/chart_2027_locked_in.png)

## What is in the repo

| Path | What it does |
| --- | --- |
| `data/raw/sec_xbrl_facts_alphabet.csv` | 269 facts from the SEC XBRL companyconcept API: CapEx, depreciation, revenue (two tags), operating income; Alphabet 2013+ and Google Inc. 2007-2014 |
| `data/raw/manual_filing_inputs.csv` | Items outside those four XBRL concepts (construction in progress, unpaid CapEx, finance-lease additions, guidance, Q3 2026 operating income), each with its filing |
| `sql/01-04_*.sql` | BigQuery Standard SQL: map tags, keep the latest filing per period, turn year-to-date facts into quarters, build model inputs, run tie-out checks |
| `pipeline/run_local_duckdb.py` | Lints the SQL as BigQuery dialect (sqlglot), runs it unchanged on DuckDB, writes `data/processed/` |
| `pipeline/run_bigquery.sh` | Same SQL on BigQuery (the free Sandbox works) |
| `pipeline/fetch_sec_xbrl.py` | Refreshes the raw facts from the SEC API |
| `model/depreciation_model.py` | Vintage engine, calibration, backtest, forecast, scenarios, margin math; writes `model/outputs/` |
| `excel/Alphabet_Depreciation_Margin_Model.xlsx` | 9-tab planning model, 1,045 live formulas, 15 checks; ties to Python within $1M at default inputs |
| `excel/build_excel_model.py` | Builds the workbook from the model outputs |
| `tests/test_model.py` | Engine vs reference loop, no FAIL tie-outs, Excel math vs Python |
| `docs/cfo_memo.md` | One-page CFO memo |

## Run it

```bash
pip install -r requirements.txt
python3 pipeline/run_local_duckdb.py      # SQL pipeline on DuckDB + tie-out report
python3 model/depreciation_model.py       # about 15 seconds; writes model/outputs/
python3 excel/build_excel_model.py        # rebuilds the workbook; open it in Excel or Google Sheets
python3 tests/test_model.py

PROJECT=your-gcp-project bash pipeline/run_bigquery.sh                     # optional: BigQuery
SEC_USER_AGENT="Your Name you@example.com" python3 pipeline/fetch_sec_xbrl.py  # optional: refresh data
```

## Method

1. **Data.** The pipeline keeps the latest filing for each period, so restated comparatives replace first-reported values. Cash flow items are reported year to date, so quarters are derived (Q2 = 6M less 3M, and so on), only when the prior year-to-date fact exists. Alphabet tagged revenue with two different XBRL elements over time; both map to one concept.
2. **Tie-outs.** Derived quarters vs reported 3-month figures; first-reported vs latest annual values (restatements); quarter completeness; 9M 2026 totals vs control totals hand-keyed from the 10-Q; no negative quarters. Current status: no FAIL; one WARN (Q3 2015 CapEx, a restatement between filings, outside the model's sensitivity window).
3. **Vintage engine.** Each quarter's spend (cash CapEx + change in unpaid CapEx + finance-lease assets + acquired P&E) splits into servers and network, buildings, other assets and land. Servers, network and buildings wait in construction in progress and go into service at a fitted rate per quarter. Straight-line depreciation starts the quarter after an asset goes live. The 2021 and 2023 useful-life changes are applied prospectively (remaining book value over remaining new life).
4. **Calibration.** Grid search on spend mix by period, go-live rates and building life against quarterly depreciation, annual depreciation and construction in progress. The backtest fits on data through Dec 2024 only. The forecast fits on all data through Q3 2026, with the 2026+ server share anchored to the CFO's disclosure (about 65%), because three quarters of data cannot pin it down.
5. **Excel.** The workbook rebuilds the forecast from Sep 30, 2026: in-service run-off (from Python) + construction in progress going live + new CapEx, all live formulas, with scenario switches and a margin guardrail.

## Key assumptions

- 2026 CapEx $200B (midpoint of $195-205B guidance); 2027 base $300B (+50%; the company has said only "increase significantly"); 2028 +10%
- 2026+ server and network share of spend 65%; servers and network 6-year life; buildings about 15 years (fitted)
- Q4 2026 revenue +22% and non-depreciation costs +20% year over year (Q3: +24.7%, +20.0%); 2027 revenue +19%

## Limits

- One blended life per asset class; no impairments or early retirements; network gear shares the server life
- Construction-in-progress timing is a fitted average, not project-level data
- The 2026 server share is anchored to one CFO comment; each 5 points moves 2027E by about $1.2B
- 2027 CapEx and revenue growth are assumptions until the Q4 2026 call

## Sources

- [Alphabet 10-Q, Q3 2026](https://www.sec.gov/Archives/edgar/data/1652044/000165204426000084/goog-20260930.htm)
- [Alphabet 10-K, FY2025](https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/goog-20251231.htm)
- [Alphabet Q3 2026 earnings call transcript](https://s206.q4cdn.com/479360582/files/doc_events/2026/Oct/28/2026_Q3_Earnings_Transcript.pdf)
- [SEC XBRL companyconcept API](https://data.sec.gov/api/xbrl/companyconcept/CIK0001652044/us-gaap/Depreciation.json)
- [Webull: Yorkville's 2027 CapEx view](https://www.webull.com/news/15832742687962112)
- [Hudson Labs: Amazon's 2025 server useful-life change](https://www.hudson-labs.com/research/amazon-server-depreciation-amzn)
