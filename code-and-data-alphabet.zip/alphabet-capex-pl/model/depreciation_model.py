"""
Alphabet CapEx-to-depreciation planning model

What it does
  1. Builds quarterly asset additions from the SQL pipeline output (cash CapEx + change in unpaid CapEx
     + finance-lease assets + acquired P&E), 2007 to Q3 2026, then forecast CapEx to 2028
  2. Runs a vintage engine: each quarter's spend is split into servers/network, buildings, other and land;
     servers/network and buildings wait in construction in progress (CIP) and go into service at a fitted
     rate per quarter; straight-line depreciation starts the quarter after an asset goes into service;
     useful-life changes are prospective (remaining book value over remaining new life), as Alphabet did
     in 2021 and 2023
  3. Fits the unknown parameters (spend mix, CIP speed, building life) by grid search
       a. out of sample: fit on data through Dec 2024 only, then score Q1 2025 to Q3 2026
       b. full: fit on all data through Q3 2026, used for the forecast
  4. Forecasts 2026E to 2028E depreciation, the locked-in share, CapEx scenarios, useful-life risk
     and the 2027 margin math; writes model/outputs/*.json and *.csv for the Excel file and the deck

All $ in millions. Run: python3 model/depreciation_model.py   (needs numpy; about 15 seconds)
"""
import csv
import itertools
import json
import pathlib

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parents[1]
PROC, RAW, OUT = ROOT / 'data' / 'processed', ROOT / 'data' / 'raw', ROOT / 'model' / 'outputs'

QUARTERS = [(y, q) for y in range(2007, 2029) for q in (1, 2, 3, 4)]
IDX = {k: i for i, k in enumerate(QUARTERS)}
T = len(QUARTERS)
LAST_ACTUAL = (2026, 3)
CUT = IDX[LAST_ACTUAL]

# ------------------------------------------------------------------ assumptions (labelled, editable)
ASSUME = {
    'capex_fy2026_guidance_mid': 200000,      # midpoint of $195-205B (Q3 2026 earnings call)
    'capex_2027': {'low': 250000, 'base': 300000, 'high': 350000},   # company: "significant increase"
    'capex_2027_quarter_weights': [0.22, 0.24, 0.26, 0.28],
    'capex_2028_growth': 0.10,
    'q4_2026_revenue_growth_yoy': 0.22,       # Q3 2026 was +24.7%
    'q4_2026_nondep_cost_growth_yoy': 0.20,   # Q3 2026 was +20.0%
    'revenue_growth_2027_cases': [0.15, 0.19, 0.23],
    'useful_life_risk_years': 5,              # servers/network from 6 to 5 years, Jan 2027
}
OTHER_SHARE, LAND_SHARE, OTHER_LIFE_Q = 0.04, 0.05, 28   # corporate/other assets ~7 years; land never depreciates

GRID = dict(e0=[0.40, 0.50], e1=[0.45, 0.55], e2=[0.50, 0.55, 0.60], e3=[0.50, 0.55, 0.60, 0.65],
            pE=[0.15, 0.20, 0.25, 0.30, 0.35, 0.40], pB=[0.05, 0.065, 0.08, 0.10, 0.13], LB=[10, 12, 15, 20, 25])
# 2026+ servers/network share of additions. Three quarters of 2026 data barely pin it down (fit loss is flat
# from 0.60 to 0.75), so it is anchored to the CFO's Q3 2026 disclosure: about 65% of spend to servers + network.
E4_DISCLOSED = 0.65
W_ANNUAL_ONLY, W_CIP = 4.0, 0.25          # an annual target counts like four quarters


# ------------------------------------------------------------------ inputs
def _f(x):
    return float(x) if x not in ('', None) else None


def load_inputs():
    annual = {int(r['fiscal_year']): {k: _f(v) for k, v in r.items()} for r in csv.DictReader(open(PROC / 'model_inputs_annual.csv'))}
    quarterly = {(int(r['fiscal_year']), int(r['fiscal_quarter'])): {k: _f(v) if k not in ('quarter_label', 'flags') else v
                                                                      for k, v in r.items()}
                 for r in csv.DictReader(open(PROC / 'model_inputs_quarterly.csv'))}
    manual = {(r['item'], r['period_or_date']): float(r['value_musd']) for r in csv.DictReader(open(RAW / 'manual_filing_inputs.csv'))}
    return annual, quarterly, manual


def build_additions(inp, capex_2027=None, capex_q4_2026=None, capex_2028=None, zero_after_cut=False):
    """Quarterly asset additions, accrual basis. Forecast quarters are cash CapEx assumptions."""
    annual, quarterly, manual = inp
    add = np.zeros(T)
    for (y, q), i in IDX.items():
        if y < 2015:
            add[i] = annual[y]['capex_musd'] / 4
        elif (y, q) <= LAST_ACTUAL:
            add[i] = quarterly[(y, q)]['capex_musd']
    ub = lambda d: manual[('unpaid_capex_balance', d)]
    spread = {   # extra additions spread pro rata to cash CapEx within each period's reported quarters
        2024: ub('2024-12-31') - ub('2023-12-31'),
        2025: ub('2025-12-31') - ub('2024-12-31') + manual[('finance_lease_rou_additions', 'FY2025')],
        2026: ub('2026-09-30') - ub('2025-12-31') + manual[('finance_lease_rou_additions', '9M2026')],
    }
    for y, extra in spread.items():
        idx = [IDX[(y, q)] for q in (1, 2, 3, 4) if (y, q) <= LAST_ACTUAL]
        cash = add[idx].sum()
        add[idx] += extra * add[idx] / cash
    add[IDX[(2026, 1)]] += manual[('acquired_ppe_intersect', '2026Q1')]
    if zero_after_cut:
        add[CUT + 1:] = 0.0
        return add
    c26 = ASSUME['capex_fy2026_guidance_mid'] - sum(quarterly[(2026, q)]['capex_musd'] for q in (1, 2, 3))
    add[IDX[(2026, 4)]] = c26 if capex_q4_2026 is None else capex_q4_2026
    c27 = ASSUME['capex_2027']['base'] if capex_2027 is None else capex_2027
    for q, w in zip((1, 2, 3, 4), ASSUME['capex_2027_quarter_weights']):
        add[IDX[(2027, q)]] = c27 * w
    c28 = c27 * (1 + ASSUME['capex_2028_growth']) if capex_2028 is None else capex_2028
    for q in (1, 2, 3, 4):
        add[IDX[(2028, q)]] = c28 / 4
    return add


# ------------------------------------------------------------------ engine
def equip_share(y, p):
    if y < 2018: return p['e0']
    if y < 2021: return p['e1']
    if y < 2024: return p['e2']
    if y < 2026: return p['e3']
    return p['e4']


def equip_life_q(y, life_2027_q=None):
    """Servers + network, in quarters: 3y before 2021; ~4.25y blend 2021-22 (servers 4y, network 5y); 6y from 2023."""
    if y < 2021: return 12
    if y < 2023: return 17
    if life_2027_q and y >= 2027: return life_2027_q
    return 24


def straight_line(placed, life_q):
    """Depreciation of assets placed each quarter, starting the next quarter, over life_q quarters."""
    out = np.zeros(T)
    for k in range(1, min(life_q, T - 1) + 1):
        out[k:] += placed[:-k] / life_q
    return out


def run(p, add, life_2027_years=None, split_at=None):
    """Returns dict of quarterly arrays. split_at = quarter index: also returns depreciation from assets
    placed in service at or before it (the in-service run-off)."""
    e = np.array([equip_share(y, p) for y, _ in QUARTERS])
    aE, aO, aL = add * e, add * OTHER_SHARE, add * LAND_SHARE
    aB = add - aE - aO - aL
    placedE, placedB, cipE, cipB = (np.zeros(T) for _ in range(4))
    cE = cB = 0.0
    for t in range(T):
        cE += aE[t]; placedE[t] = p['pE'] * cE; cE -= placedE[t]; cipE[t] = cE
        cB += aB[t]; placedB[t] = p['pB'] * cB; cB -= placedB[t]; cipB[t] = cB

    life_2027_q = int(round(life_2027_years * 4)) if life_2027_years else None
    changes = {IDX[(2021, 1)]: 17, IDX[(2023, 1)]: 24}
    if life_2027_q:
        changes[IDX[(2027, 1)]] = life_2027_q
    life = np.array([equip_life_q(y, life_2027_q) for y, _ in QUARTERS], dtype=float)
    nbv, rem = np.zeros(T), np.zeros(T)
    depE, depE_in = np.zeros(T), np.zeros(T)
    ages_all = np.arange(T)
    for t in range(T):
        if t in changes:
            rem[:t] = np.maximum(changes[t] - (t - ages_all[:t]), 1)
        act = (nbv[:t] > 1e-9) & (rem[:t] > 0)
        x = np.where(act, nbv[:t] / np.where(rem[:t] > 0, rem[:t], 1), 0.0)
        nbv[:t] -= x
        rem[:t] -= act
        depE[t] = x.sum()
        if split_at is not None:
            depE_in[t] = x[:split_at + 1].sum()
        nbv[t], rem[t] = placedE[t], life[t]

    LBq = int(p['LB'] * 4)
    depB, depO = straight_line(placedB, LBq), straight_line(aO, OTHER_LIFE_Q)
    res = dict(dep=depE + depB + depO, depE=depE, depB=depB, depO=depO, cip=cipE + cipB, cipE=cipE, cipB=cipB,
               placedE=placedE, placedB=placedB, aE=aE, aB=aB, aO=aO, add=add)
    if split_at is not None:
        mask = np.arange(T) <= split_at
        res['dep_inservice'] = depE_in + straight_line(placedB * mask, LBq) + straight_line(aO * mask, OTHER_LIFE_Q)
    return res


def ysum(arr, y, quarters=(1, 2, 3, 4)):
    return float(sum(arr[IDX[(y, q)]] for q in quarters))


# ------------------------------------------------------------------ calibration
def targets(inp):
    annual, quarterly, manual = inp
    dep_q = {k: v['depreciation_musd'] for k, v in quarterly.items() if v['depreciation_musd'] is not None}
    dep_annual_only = {y: annual[y]['depreciation_musd'] for y in (2021, 2022)}
    cip = {(2024, 4): manual[('construction_in_progress', '2024-12-31')],
           (2025, 4): manual[('construction_in_progress', '2025-12-31')],
           (2026, 3): manual[('construction_in_progress', '2026-09-30')]}
    return dep_q, dep_annual_only, cip


def loss(p, add, tg, upto):
    dep_q, dep_a, cip = tg
    r = run(p, add)
    e2 = [(r['dep'][IDX[k]] / v - 1) ** 2 for k, v in dep_q.items() if k <= upto]
    e2 += [W_ANNUAL_ONLY * (ysum(r['dep'], y) / v - 1) ** 2 for y, v in dep_a.items() if (y, 4) <= upto]
    e2 += [W_CIP * (r['cip'][IDX[k]] / v - 1) ** 2 for k, v in cip.items() if k <= upto]
    return float(sum(e2))


def ranked_fits(add, tg, upto, e4=None):
    """e4=None: carry the latest fitted mix (e3) forward, as an analyst would before any 2026 data."""
    keys = list(GRID)
    fits = []
    for combo in itertools.product(*[GRID[k] for k in keys]):
        p = dict(zip(keys, combo))
        p['e4'] = p['e3'] if e4 is None else e4
        fits.append((loss(p, add, tg, upto), p))
    return sorted(fits, key=lambda f: f[0])


# ------------------------------------------------------------------ main
def main():
    OUT.mkdir(parents=True, exist_ok=True)
    inp = load_inputs()
    annual, quarterly, manual = inp
    tg = targets(inp)
    dep_q = tg[0]
    add_base = build_additions(inp)

    # a. out-of-sample backtest
    oos = ranked_fits(add_base, tg, upto=(2024, 4))
    p_oos = oos[0][1]
    r = run(p_oos, add_base)
    test_q = [k for k in sorted(dep_q) if (2025, 1) <= k <= LAST_ACTUAL]
    backtest = [dict(quarter=f'{y}Q{q}', model=round(float(r['dep'][IDX[(y, q)]]), 1), actual=dep_q[(y, q)],
                     error=float(r['dep'][IDX[(y, q)]] / dep_q[(y, q)] - 1)) for y, q in test_q]
    mape = float(np.mean([abs(b['error']) for b in backtest]))
    fy25_m, fy25_a = ysum(r['dep'], 2025), annual[2025]['depreciation_musd']
    m9_m, m9_a = ysum(r['dep'], 2026, (1, 2, 3)), sum(dep_q[(2026, q)] for q in (1, 2, 3))
    cip_bt = {k: dict(model=float(r['cip'][IDX[k]]), actual=v, error=float(r['cip'][IDX[k]] / v - 1))
              for k, v in tg[2].items() if k > (2024, 4)}
    fits_in_oos = [dict(quarter=f'{y}Q{q}', model=round(float(r['dep'][IDX[(y, q)]]), 1), actual=dep_q[(y, q)])
                   for y, q in sorted(dep_q) if (y, q) <= (2024, 4)]

    # b. full fit for the forecast
    full = ranked_fits(add_base, tg, upto=LAST_ACTUAL, e4=E4_DISCLOSED)
    P = full[0][1]
    base = run(P, add_base, split_at=CUT)
    locked = run(P, build_additions(inp, zero_after_cut=True))
    life = run(P, add_base, life_2027_years=ASSUME['useful_life_risk_years'])
    dep26 = m9_a + float(base['dep'][IDX[(2026, 4)]])
    dep27, dep28 = ysum(base['dep'], 2027), ysum(base['dep'], 2028)
    lock27, lock28 = ysum(locked['dep'], 2027), ysum(locked['dep'], 2028)
    inserv27 = ysum(base['dep_inservice'], 2027)

    scen = {}
    for name, c27 in ASSUME['capex_2027'].items():
        rs = run(P, build_additions(inp, capex_2027=c27))
        scen[name] = dict(capex_2027=c27, dep_2027=ysum(rs['dep'], 2027), dep_2028=ysum(rs['dep'], 2028))

    top = []
    for _, p in full[:15]:
        a, lk, lf = run(p, add_base), run(p, build_additions(inp, zero_after_cut=True)), run(p, add_base, life_2027_years=ASSUME['useful_life_risk_years'])
        d = ysum(a['dep'], 2027)
        top.append(dict(dep_2027=d, locked_share=ysum(lk['dep'], 2027) / d, life_effect=ysum(lf['dep'], 2027) - d))

    e4_sens = {f'{e:.2f}': ysum(run(dict(P, e4=e), add_base)['dep'], 2027) for e in (0.60, 0.65, 0.70)}

    # in-sample fit of the full model
    fit_full = [dict(quarter=f'{y}Q{q}', model=round(float(base['dep'][IDX[(y, q)]]), 1), actual=dep_q[(y, q)],
                     error=float(base['dep'][IDX[(y, q)]] / dep_q[(y, q)] - 1)) for y, q in sorted(dep_q)]

    # c. 2026E and 2027 margin math (actuals from the pipeline; Q4 2026 assumptions labelled above)
    rev = lambda y, q: quarterly[(y, q)]['revenue_musd']
    oi = lambda y, q: quarterly[(y, q)]['operating_income_musd']
    dq = lambda y, q: quarterly[(y, q)]['depreciation_musd']
    cost = lambda y, q: rev(y, q) - oi(y, q) - dq(y, q)       # costs other than depreciation
    rev25, oi25, d25 = annual[2025]['revenue_musd'], annual[2025]['operating_income_musd'], annual[2025]['depreciation_musd']
    cost25 = rev25 - oi25 - d25
    rev26_q4 = rev(2025, 4) * (1 + ASSUME['q4_2026_revenue_growth_yoy'])
    cost26_q4 = cost(2025, 4) * (1 + ASSUME['q4_2026_nondep_cost_growth_yoy'])
    rev26 = sum(rev(2026, q) for q in (1, 2, 3)) + rev26_q4
    cost26 = sum(cost(2026, q) for q in (1, 2, 3)) + cost26_q4
    oi26 = rev26 - cost26 - dep26
    m26, g_cost26 = oi26 / rev26, cost26 / cost25 - 1
    margin_cases = []
    for g in ASSUME['revenue_growth_2027_cases']:
        rev27 = rev26 * (1 + g)
        neutral = (rev27 * (1 - m26) - dep27) / cost26 - 1
        same_pace = (rev27 - cost26 * (1 + g_cost26) - dep27) / rev27
        margin_cases.append(dict(revenue_growth=g, revenue_2027=rev27, dep_pct_revenue=dep27 / rev27,
                                 margin_neutral_cost_growth=neutral, margin_at_2026_cost_pace=same_pace))

    out = dict(
        params_out_of_sample=p_oos, params_full=P,
        backtest=dict(quarters=backtest, mape=mape, fy2025=dict(model=fy25_m, actual=fy25_a, error=fy25_m / fy25_a - 1),
                      nine_months_2026=dict(model=m9_m, actual=m9_a, error=m9_m / m9_a - 1),
                      cip={f'{y}Q{q}': v for (y, q), v in cip_bt.items()}, in_sample=fits_in_oos),
        fit_full=fit_full,
        forecast=dict(dep_2026E=dep26, dep_q4_2026E=float(base['dep'][IDX[(2026, 4)]]), dep_2027E=dep27, dep_2028E=dep28,
                      growth_2027=dep27 / dep26 - 1, locked_2027=lock27, locked_share_2027=lock27 / dep27,
                      inservice_runoff_2027=inserv27, cip_drain_2027=lock27 - inserv27, new_capex_2027=dep27 - lock27,
                      locked_2028=lock28, locked_share_2028=lock28 / dep28,
                      life_risk_2027=ysum(life['dep'], 2027) - dep27, life_risk_2028=ysum(life['dep'], 2028) - dep28,
                      capex_q4_2026E=float(add_base[IDX[(2026, 4)]]),
                      cip_model_2026Q3=float(base['cip'][CUT]), cipE_2026Q3=float(base['cipE'][CUT]), cipB_2026Q3=float(base['cipB'][CUT])),
        scenarios=scen,
        e4_sensitivity_dep_2027=e4_sens,
        range_2027_from_backtest_errors=[dep27 * (1 + min(b['error'] for b in backtest)),
                                         dep27 * (1 + max(b['error'] for b in backtest))],
        robustness_top15=dict(dep_2027=[min(t['dep_2027'] for t in top), max(t['dep_2027'] for t in top)],
                              locked_share=[min(t['locked_share'] for t in top), max(t['locked_share'] for t in top)],
                              life_effect=[min(t['life_effect'] for t in top), max(t['life_effect'] for t in top)]),
        margin=dict(rev_2025=rev25, oi_2025=oi25, cost_2025=cost25, margin_2025=oi25 / rev25,
                    rev_q4_2026E=rev26_q4, cost_q4_2026E=cost26_q4, rev_2026E=rev26, cost_2026E=cost26, oi_2026E=oi26,
                    margin_2026E=m26, cost_growth_2026E=g_cost26, dep_pct_rev_2025=d25 / rev25, dep_pct_rev_2026E=dep26 / rev26,
                    cases_2027=margin_cases),
        capex_to_dep={str(y): annual[y]['capex_musd'] / annual[y]['depreciation_musd'] for y in range(2021, 2026)} | {
            '2026E': ASSUME['capex_fy2026_guidance_mid'] / dep26},
        assumptions=ASSUME,
    )
    (OUT / 'results.json').write_text(json.dumps(out, indent=1))

    # quarterly forecast table for the deck and the Excel file
    with open(OUT / 'forecast_quarterly.csv', 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['quarter', 'additions_musd', 'dep_total_musd', 'dep_locked_in_musd', 'dep_inservice_runoff_musd',
                    'dep_new_capex_musd', 'cip_model_musd', 'dep_actual_musd'])
        for (y, q), i in IDX.items():
            if y >= 2021:
                act = quarterly.get((y, q), {}).get('depreciation_musd')
                w.writerow([f'{y}Q{q}', round(float(base['add'][i]), 1), round(float(base['dep'][i]), 1),
                            round(float(locked['dep'][i]), 1), round(float(base['dep_inservice'][i]), 1),
                            round(float(base['dep'][i] - locked['dep'][i]), 1), round(float(base['cip'][i]), 1),
                            '' if act is None else act])
    # Excel feed: opening state at Sep 30, 2026 (exact, not rounded) so the workbook can rebuild the forecast
    feed = dict(params=P, other_share=OTHER_SHARE, land_share=LAND_SHARE, life_equip_q=24, life_build_q=int(P['LB'] * 4),
                life_other_q=OTHER_LIFE_Q, cipE_open=float(base['cipE'][CUT]), cipB_open=float(base['cipB'][CUT]),
                runoff={f'{y}Q{q}': float(base['dep_inservice'][IDX[(y, q)]]) for (y, q) in QUARTERS if (y, q) > LAST_ACTUAL},
                forecast_capex={f'{y}Q{q}': float(add_base[IDX[(y, q)]]) for (y, q) in QUARTERS if (y, q) > LAST_ACTUAL},
                dep_total={f'{y}Q{q}': float(base['dep'][IDX[(y, q)]]) for (y, q) in QUARTERS if (y, q) > LAST_ACTUAL})
    (OUT / 'excel_feed.json').write_text(json.dumps(feed, indent=1))
    return out


def report(o):
    pct = lambda x: f'{x:+.1%}'
    print('params, fit through Dec 2024 only:', o['params_out_of_sample'])
    print('params, fit through Sep 2026     :', o['params_full'])
    b = o['backtest']
    print('\nOUT-OF-SAMPLE BACKTEST (depreciation, $M)')
    for r in b['quarters']:
        print(f"  {r['quarter']}  model {r['model']:8,.0f}  actual {r['actual']:8,.0f}  error {pct(r['error'])}")
    print(f"  mean absolute error, 7 quarters: {b['mape']:.1%}")
    print(f"  FY2025  model {b['fy2025']['model']:,.0f} actual {b['fy2025']['actual']:,.0f} error {pct(b['fy2025']['error'])}")
    print(f"  9M 2026 model {b['nine_months_2026']['model']:,.0f} actual {b['nine_months_2026']['actual']:,.0f} error {pct(b['nine_months_2026']['error'])}")
    for k, v in b['cip'].items():
        print(f"  CIP {k}: model {v['model']:,.0f} actual {v['actual']:,.0f} error {pct(v['error'])}")
    f = o['forecast']
    print('\nFORECAST (full fit)')
    print(f"  2026E {f['dep_2026E']:,.0f} (9M actual + Q4E {f['dep_q4_2026E']:,.0f});  2027E {f['dep_2027E']:,.0f} ({pct(f['growth_2027'])});  2028E {f['dep_2028E']:,.0f}")
    print(f"  locked-in 2027: {f['locked_2027']:,.0f} = {f['locked_share_2027']:.1%} (in-service run-off {f['inservice_runoff_2027']:,.0f} + CIP going live {f['cip_drain_2027']:,.0f}); new CapEx {f['new_capex_2027']:,.0f}")
    print(f"  locked-in 2028: {f['locked_2028']:,.0f} = {f['locked_share_2028']:.1%}")
    print(f"  useful life 6y -> 5y from Jan 2027: 2027 +{f['life_risk_2027']:,.0f}, 2028 +{f['life_risk_2028']:,.0f}")
    print(f"  model CIP Sep 2026 {f['cip_model_2026Q3']:,.0f} (actual 145,270)")
    for k, s in o['scenarios'].items():
        print(f"  CapEx 2027 {s['capex_2027'] / 1000:.0f}B ({k}): 2027E {s['dep_2027']:,.0f}  2028E {s['dep_2028']:,.0f}")
    print('  2026+ server share sensitivity (2027E):', {k: round(v) for k, v in o['e4_sensitivity_dep_2027'].items()})
    rb = o['robustness_top15']
    print(f"  top-15 fits: 2027E {rb['dep_2027'][0]:,.0f}-{rb['dep_2027'][1]:,.0f}; locked {rb['locked_share'][0]:.0%}-{rb['locked_share'][1]:.0%}; 5y life +{rb['life_effect'][0]:,.0f} to +{rb['life_effect'][1]:,.0f}")
    m = o['margin']
    print('\nMARGIN')
    print(f"  2025 margin {m['margin_2025']:.1%}; 2026E revenue {m['rev_2026E']:,.0f}, OI {m['oi_2026E']:,.0f}, margin {m['margin_2026E']:.1%}, non-dep cost growth {pct(m['cost_growth_2026E'])}")
    print(f"  dep/revenue 2025 {m['dep_pct_rev_2025']:.1%}, 2026E {m['dep_pct_rev_2026E']:.1%}")
    for c in m['cases_2027']:
        print(f"  2027 revenue {pct(c['revenue_growth'])}: dep/rev {c['dep_pct_revenue']:.1%}; margin-neutral cost growth {pct(c['margin_neutral_cost_growth'])}; margin at 2026 cost pace {c['margin_at_2026_cost_pace']:.1%}")
    print('  CapEx/depreciation:', {k: round(v, 1) for k, v in o['capex_to_dep'].items()})


if __name__ == '__main__':
    report(main())
