# Hand-keyed filing inputs

Items here are not in the four SEC XBRL concepts the pipeline pulls (or were missing from the API at pull time).
Each row names the filing it came from. Re-key and re-check them after every new 10-Q or 10-K.

Qualitative inputs used in the model (not numeric rows):
- Useful life of servers and network equipment: 6 years since January 2023 (10-K FY2025, property and equipment policy). Earlier: servers 4 years and network 5 years from January 2021; 3 years before that.
- Q3 2026 earnings call (CFO): about 65% of technical infrastructure spend in Q3 went to servers and network equipment (6-year life), about 35% to data centers (longer lives).
- Q3 2026 earnings call (CFO): 2027 CapEx expected to increase significantly; details on the Q4 call.
