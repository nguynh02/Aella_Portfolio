#!/usr/bin/env bash
# Run the SQL pipeline on BigQuery (the free BigQuery Sandbox works).
# Needs the Google Cloud CLI (bq) and: gcloud auth login
# Usage: PROJECT=your-gcp-project-id bash pipeline/run_bigquery.sh
set -euo pipefail
PROJECT="${PROJECT:?Set PROJECT to your Google Cloud project id}"
cd "$(dirname "$0")/.."

bq --project_id="$PROJECT" mk --force --dataset finance

bq --project_id="$PROJECT" load --replace --source_format=CSV --skip_leading_rows=1 \
  finance.raw_xbrl_facts data/raw/sec_xbrl_facts_alphabet.csv sql/schema/raw_xbrl_facts.json
bq --project_id="$PROJECT" load --replace --source_format=CSV --skip_leading_rows=1 \
  finance.manual_inputs data/raw/manual_filing_inputs.csv sql/schema/manual_inputs.json

for f in sql/0*.sql; do
  echo "running $f"
  bq --project_id="$PROJECT" query --use_legacy_sql=false < "$f"
done

mkdir -p data/processed/bigquery
for t in model_inputs_quarterly model_inputs_annual tieout_report; do
  bq --project_id="$PROJECT" query --use_legacy_sql=false --format=csv --max_rows=10000 \
    "SELECT * FROM finance.$t" > "data/processed/bigquery/$t.csv"
  echo "wrote data/processed/bigquery/$t.csv"
done
echo "Compare with the DuckDB outputs in data/processed/ (same SQL, same numbers expected)."
