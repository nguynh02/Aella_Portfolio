"""
Refresh data/raw/sec_xbrl_facts_alphabet.csv from the SEC XBRL companyconcept API.

The SEC asks every client to identify itself, so set SEC_USER_AGENT to your own name and email:
  SEC_USER_AGENT="Jane Doe jane.doe@example.com" python3 pipeline/fetch_sec_xbrl.py

Pulls duration facts (10-K and 10-Q, amendments included) for the tags the pipeline maps. Every filing's copy
of a fact is kept; sql/01_clean_facts.sql picks the latest filing per period. Stays under the SEC's
10 requests per second limit.
"""
import csv
import json
import os
import pathlib
import sys
import time
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / 'data' / 'raw' / 'sec_xbrl_facts_alphabet.csv'
URL = 'https://data.sec.gov/api/xbrl/companyconcept/CIK{cik:010d}/us-gaap/{tag}.json'
PULLS = [
    (1652044, 'PaymentsToAcquirePropertyPlantAndEquipment'),
    (1652044, 'Depreciation'),
    (1652044, 'Revenues'),
    (1652044, 'RevenueFromContractWithCustomerExcludingAssessedTax'),
    (1652044, 'OperatingIncomeLoss'),
    (1288776, 'PaymentsToAcquirePropertyPlantAndEquipment'),   # Google Inc., the pre-2015 registrant
]
PEER_OUT = ROOT / 'data' / 'raw' / 'sec_xbrl_facts_peers.csv'
PEER_PULLS = [   # CapEx for the hyperscaler tracker (Amazon tags it as productive assets)
    (789019, 'PaymentsToAcquirePropertyPlantAndEquipment'),    # Microsoft
    (1018724, 'PaymentsToAcquireProductiveAssets'),            # Amazon
    (1326801, 'PaymentsToAcquirePropertyPlantAndEquipment'),   # Meta
    (1341439, 'PaymentsToAcquirePropertyPlantAndEquipment'),   # Oracle
]
PEER_FROM = '2023-06-01'    # the tracker needs recent quarters only
FORMS = {'10-K', '10-Q', '10-K/A', '10-Q/A'}
COLUMNS = ['cik', 'company', 'tag', 'period_start', 'period_end', 'value_usd', 'fy', 'fp', 'form', 'filed']


def fetch(cik, tag, user_agent):
    req = urllib.request.Request(URL.format(cik=cik, tag=tag), headers={'User-Agent': user_agent, 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def flatten(doc, tag):
    """One row per USD duration fact. Instant facts (no start date) are skipped."""
    rows = []
    for f in doc.get('units', {}).get('USD', []):
        if 'start' not in f or f.get('form') not in FORMS:
            continue
        rows.append({'cik': doc['cik'], 'company': doc.get('entityName', ''), 'tag': tag,
                     'period_start': f['start'], 'period_end': f['end'], 'value_usd': int(f['val']),
                     'fy': f.get('fy', ''), 'fp': f.get('fp', ''), 'form': f['form'], 'filed': f['filed']})
    return rows


def main():
    user_agent = os.environ.get('SEC_USER_AGENT', '').strip()
    if '@' not in user_agent:
        sys.exit('Set SEC_USER_AGENT to "Your Name your.email@example.com" (SEC fair-access policy).')
    for pulls, out, since in ((PULLS, OUT, None), (PEER_PULLS, PEER_OUT, PEER_FROM)):
        rows = []
        for cik, tag in pulls:
            got = [r for r in flatten(fetch(cik, tag, user_agent), tag) if since is None or r['period_start'] >= since]
            print(f'{cik} {tag}: {len(got)} facts')
            rows += got
            time.sleep(0.25)
        rows.sort(key=lambda r: (r['cik'], r['tag'], r['period_end'], r['period_start'], r['filed']))
        with open(out, 'w', newline='') as fh:
            w = csv.DictWriter(fh, fieldnames=COLUMNS)
            w.writeheader()
            w.writerows(rows)
        print(f'wrote {len(rows)} facts to {out}')
    print('next: bash watch/refresh.sh')


if __name__ == '__main__':
    main()
