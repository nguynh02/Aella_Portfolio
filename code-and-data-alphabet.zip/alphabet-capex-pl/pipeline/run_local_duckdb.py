"""
Run the BigQuery SQL pipeline locally on DuckDB (same SQL files, no edits).

  1. Lint: parse every SQL file as BigQuery Standard SQL (sqlglot) so dialect slips fail fast
  2. Load data/raw CSVs into finance.raw_xbrl_facts and finance.manual_inputs
  3. Run sql/01..04 in order
  4. Write data/processed/*.csv and print the tie-out summary; exit 1 if any check FAILs

Usage: python3 pipeline/run_local_duckdb.py
Needs: pip install duckdb sqlglot
"""
import pathlib
import sys

import duckdb
import sqlglot

ROOT = pathlib.Path(__file__).resolve().parents[1]
SQL_FILES = sorted((ROOT / 'sql').glob('0*.sql'))
RAW = ROOT / 'data' / 'raw'
OUT = ROOT / 'data' / 'processed'


def lint_bigquery(path):
    sqlglot.parse(path.read_text(), read='bigquery')   # raises sqlglot.errors.ParseError on bad syntax


def main():
    for f in SQL_FILES:
        lint_bigquery(f)
    print(f'lint: {len(SQL_FILES)} SQL files parse as BigQuery Standard SQL')

    con = duckdb.connect()
    con.execute('CREATE SCHEMA IF NOT EXISTS finance')
    con.execute(f"""
        CREATE OR REPLACE TABLE finance.raw_xbrl_facts AS
        SELECT * FROM read_csv('{RAW / 'sec_xbrl_facts_alphabet.csv'}', header = true, columns = {{
            'cik': 'BIGINT', 'company': 'VARCHAR', 'tag': 'VARCHAR', 'period_start': 'DATE',
            'period_end': 'DATE', 'value_usd': 'BIGINT', 'fy': 'BIGINT', 'fp': 'VARCHAR',
            'form': 'VARCHAR', 'filed': 'DATE'}})""")
    con.execute(f"""
        CREATE OR REPLACE TABLE finance.manual_inputs AS
        SELECT * FROM read_csv('{RAW / 'manual_filing_inputs.csv'}', header = true, columns = {{
            'item': 'VARCHAR', 'period_or_date': 'VARCHAR', 'value_musd': 'DOUBLE',
            'source': 'VARCHAR', 'note': 'VARCHAR'}})""")
    n_raw = con.execute('SELECT COUNT(*) FROM finance.raw_xbrl_facts').fetchone()[0]
    print(f'loaded {n_raw} raw XBRL facts')

    for f in SQL_FILES:
        con.execute(f.read_text())
        print(f'ran {f.name}')

    OUT.mkdir(parents=True, exist_ok=True)
    exports = {
        'model_inputs_quarterly': 'ORDER BY fiscal_year, fiscal_quarter',
        'model_inputs_annual': 'ORDER BY fiscal_year',
        'tieout_report': 'ORDER BY check_name, concept, period',
    }
    for table, order in exports.items():
        con.execute(f"COPY (SELECT * FROM finance.{table} {order}) TO '{OUT / (table + '.csv')}' (HEADER, DELIMITER ',')")
        print(f'wrote data/processed/{table}.csv')

    summary = con.execute("""
        SELECT check_name, status, COUNT(*) FROM finance.tieout_report
        GROUP BY check_name, status ORDER BY check_name, status""").fetchall()
    print('\ntie-out summary')
    for name, status, n in summary:
        print(f'  {name:30s} {status:5s} {n}')
    flagged = con.execute("""
        SELECT check_name, concept, period, expected_musd, actual_musd, diff_musd, status, note
        FROM finance.tieout_report WHERE status <> 'PASS' ORDER BY check_name, period""").fetchall()
    if flagged:
        print('\nnot PASS')
        for r in flagged:
            print(f'  {r[6]:4s} {r[0]:28s} {r[1]:16s} {r[2]:10s} expected {r[3]:>10,.1f} actual {r[4]:>10,.1f} diff {r[5]:>+8,.1f}  {r[7]}')
    fails = sum(n for _, status, n in summary if status == 'FAIL')
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()
