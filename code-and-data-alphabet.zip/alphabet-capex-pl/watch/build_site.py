"""
Builds the dashboard as one self-contained page: site/index.html (inline SVG charts, a small what-if script).
Run after score_forecasts.py and make_flash.py:  python3 watch/build_site.py
"""
import csv
import datetime
import html
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
PROC, OUT, SITE = ROOT / 'data' / 'processed', ROOT / 'model' / 'outputs', ROOT / 'site'
BLUE, RED, YELLOW, GREEN, GREY, INK, MUTED, LINE = '#4285F4', '#EA4335', '#FBBC04', '#34A853', '#BDC1C6', '#202124', '#5F6368', '#DADCE0'
COMPANY_COLOR = {'Alphabet': BLUE, 'Amazon': YELLOW, 'Microsoft': GREEN, 'Meta': RED, 'Oracle': '#80868B'}


def forecast_chart(log):
    W, H, left, base, top = 920, 360, 20, 300, 60
    peak = max(max(float(r['forecast_musd']), float(r['actual_musd'] or 0)) for r in log) * 1.08
    band = (W - 2 * left) / len(log)
    bw = band * 0.30
    y = lambda v: base - (base - top) * v / peak
    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Quarterly depreciation: forecast versus reported">',
           f'<line x1="{left}" x2="{W - left}" y1="{base}" y2="{base}" stroke="{LINE}"/>']
    for i, r in enumerate(log):
        cx = left + band * i + band / 2
        fc = float(r['forecast_musd'])
        live = not r['actual_musd']
        out.append(f'<rect x="{cx - bw - 2:.1f}" y="{y(fc):.1f}" width="{bw:.1f}" height="{base - y(fc):.1f}" rx="3" fill="{BLUE}"'
                   + (' fill-opacity="0.35" stroke="#4285F4" stroke-dasharray="4 3"' if live else '') + f'><title>{r["quarter"]} forecast ${fc / 1000:.2f}B</title></rect>')
        if not live:
            act = float(r['actual_musd'])
            out.append(f'<rect x="{cx + 2:.1f}" y="{y(act):.1f}" width="{bw:.1f}" height="{base - y(act):.1f}" rx="3" fill="{GREY}"><title>{r["quarter"]} reported ${act / 1000:.2f}B</title></rect>')
            out.append(f'<text x="{cx:.1f}" y="{min(y(fc), y(act)) - 10:.1f}" text-anchor="middle" font-size="14" font-weight="700" fill="{INK}">{float(r["error"]):+.1%}</text>')
        else:
            out.append(f'<text x="{cx:.1f}" y="{y(fc) - 10:.1f}" text-anchor="middle" font-size="14" font-weight="700" fill="#1A73E8">${fc / 1000:.1f}B live</text>')
        out.append(f'<text x="{cx:.1f}" y="{base + 22}" text-anchor="middle" font-size="13" fill="{MUTED}">{r["quarter"][:4]} Q{r["quarter"][5]}</text>')
    out.append(f'<rect x="{left}" y="14" width="12" height="12" rx="2" fill="{BLUE}"/><text x="{left + 18}" y="25" font-size="13" fill="{MUTED}">Forecast made one quarter ahead</text>')
    out.append(f'<rect x="{left + 250}" y="14" width="12" height="12" rx="2" fill="{GREY}"/><text x="{left + 268}" y="25" font-size="13" fill="{MUTED}">Reported</text>')
    out.append(f'<text x="{left + 350}" y="25" font-size="13" fill="{MUTED}">Label = forecast error</text></svg>')
    return ''.join(out)


def peer_chart(peers):
    rows = [p for p in peers if p['capex_ttm_musd']]
    labels = sorted({p['quarter_label'] for p in rows})
    labels = [q for q in labels if all(any(p['company'] == c and p['quarter_label'] == q for p in rows) for c in COMPANY_COLOR)]
    W, H, left, right, base, top = 920, 380, 50, 150, 330, 30
    peak = max(float(p['capex_ttm_musd']) for p in rows if p['quarter_label'] in labels) * 1.05
    x = lambda i: left + (W - left - right) * i / (len(labels) - 1)
    y = lambda v: base - (base - top) * v / peak
    out = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Trailing 12-month CapEx for five hyperscalers">']
    for g in range(0, int(peak / 1000) + 1, 50):
        out.append(f'<line x1="{left}" x2="{W - right}" y1="{y(g * 1000):.1f}" y2="{y(g * 1000):.1f}" stroke="#F1F3F4"/>'
                   f'<text x="{left - 8}" y="{y(g * 1000) + 4:.1f}" text-anchor="end" font-size="12" fill="{MUTED}">${g}B</text>')
    for i, q in enumerate(labels):
        out.append(f'<text x="{x(i):.1f}" y="{base + 22}" text-anchor="middle" font-size="12" fill="{MUTED}">{q[:4]} Q{q[5]}</text>')
    for c, col in COMPANY_COLOR.items():
        pts = [(x(i), y(float(next(p for p in rows if p['company'] == c and p['quarter_label'] == q)['capex_ttm_musd']))) for i, q in enumerate(labels)]
        last = float(next(p for p in rows if p['company'] == c and p['quarter_label'] == labels[-1])['capex_ttm_musd'])
        out.append(f'<polyline fill="none" stroke="{col}" stroke-width="{4 if c == "Alphabet" else 2.5}" points="{" ".join(f"{a:.1f},{b:.1f}" for a, b in pts)}"/>')
        out.append(f'<circle cx="{pts[-1][0]:.1f}" cy="{pts[-1][1]:.1f}" r="4" fill="{col}"/>')
        out.append(f'<text x="{pts[-1][0] + 10:.1f}" y="{pts[-1][1] + 5:.1f}" font-size="13" font-weight="{700 if c == "Alphabet" else 400}" fill="{INK}">{c} ${last / 1000:.0f}B</text>')
    out.append('</svg>')
    return ''.join(out), labels[-1]


def main():
    log = list(csv.DictReader(open(OUT / 'forecast_log.csv')))
    card = json.loads((OUT / 'scorecard.json').read_text())
    res = json.loads((OUT / 'results.json').read_text())
    peers = list(csv.DictReader(open(PROC / 'peer_capex_quarterly.csv')))
    tie = list(csv.DictReader(open(PROC / 'tieout_report.csv'))) + list(csv.DictReader(open(PROC / 'peer_tieout.csv')))
    hist = [r for r in log if r['actual_musd']]
    last = hist[-1]
    f = res['forecast']
    pchart, plabel = peer_chart(peers)
    n_pass, n_fail = sum(t['status'] == 'PASS' for t in tie), sum(t['status'] == 'FAIL' for t in tie)
    score_rows = ''.join(
        f'<tr><td>{r["quarter"][:4]} Q{r["quarter"][5]}</td><td>{r["data_through"][:4]} Q{r["data_through"][5]}</td>'
        f'<td class="n">{float(r["forecast_musd"]) / 1000:.2f}</td><td class="n">{float(r["actual_musd"]) / 1000:.2f}</td>'
        f'<td class="n"><b>{float(r["error"]):+.1%}</b></td><td class="n">{float(r["no_change_error"]):+.1%}</td><td class="n">{float(r["momentum_error"]):+.1%}</td>'
        f'<td>{"inside band" if r["in_band"] == "True" else "ALERT: outside band"}</td></tr>' for r in hist)
    peer_rows = ''.join(
        f'<tr><td><span class="dot" style="background:{COMPANY_COLOR[p["company"]]}"></span>{p["company"]}</td><td class="n">{float(p["capex_musd"]) / 1000:.1f}</td>'
        f'<td class="n">{float(p["capex_yoy"]):+.0%}</td><td class="n">{float(p["capex_ttm_musd"]) / 1000:.0f}</td></tr>'
        for p in sorted((p for p in peers if p['quarter_label'] == plabel), key=lambda p: -float(p['capex_musd'])))
    m = res['margin']
    sim = json.dumps(dict(rev26=m['rev_2026E'], cost26=m['cost_2026E'], m26=m['margin_2026E'], pace=m['cost_growth_2026E'],
                          dep={k: v['dep_2027'] for k, v in res['scenarios'].items()},
                          capex={k: v['capex_2027'] for k, v in res['scenarios'].items()},
                          flash={r['quarter']: dict(f=float(r['forecast_musd']), a=float(r['actual_musd']), e=float(r['error']),
                                                    n=float(r['no_change_error']), t=r['data_through']) for r in hist}))
    today = datetime.date.today().strftime('%b %d, %Y').replace(' 0', ' ')
    page = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>AI CapEx Watch</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap">
<style>
body{{margin:0;background:#F8F9FA;color:{INK};font-family:Roboto,Arial,sans-serif;line-height:1.5}}
.bar{{display:flex;height:6px}}.bar div{{flex:1}}
main{{max-width:1000px;margin:0 auto;padding:32px 16px 64px}}
h1{{font-size:34px;font-weight:500;margin:0 0 4px}}h2{{font-size:21px;font-weight:500;margin:0 0 4px}}
.sub{{color:{MUTED};margin:0 0 24px}}.note{{color:{MUTED};font-size:14px;margin:8px 0 0}}
.tiles{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:16px;margin-bottom:24px}}
.tile{{background:#fff;border-radius:12px;padding:20px;border-top:5px solid {BLUE}}}
.tile .k{{font-size:13px;color:{MUTED};text-transform:uppercase;letter-spacing:.5px}}.tile .v{{font-size:34px;font-weight:500;line-height:1.2}}.tile .d{{font-size:14px;color:{MUTED}}}
section{{background:#fff;border-radius:12px;padding:24px;margin-bottom:24px;overflow-x:auto}}
svg{{width:100%;height:auto;min-width:640px;font-family:Roboto,Arial,sans-serif}}
table{{border-collapse:collapse;width:100%;font-size:14px;margin-top:12px}}th,td{{padding:8px 10px;border-bottom:1px solid #E8EAED;text-align:left}}
th{{background:#F1F3F4;font-weight:500}}.n{{text-align:right;font-variant-numeric:tabular-nums}}
.dot{{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px}}
footer{{color:{MUTED};font-size:13px}}
.sim{{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:24px;margin-top:16px}}
.ctl label{{display:block;margin-bottom:18px;font-size:15px}}.ctl input{{width:100%;accent-color:{BLUE}}}
.seg{{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px}}.seg button{{font:inherit;padding:8px 14px;border:1px solid {LINE};border-radius:20px;background:#fff;cursor:pointer}}
.seg button.on{{background:#E8F0FE;border-color:{BLUE};color:#174EA6;font-weight:500}}
.out{{display:grid;gap:14px}}.out>div{{background:#F8F9FA;border-radius:12px;padding:14px 18px}}
.out .k{{font-size:13px;color:{MUTED};text-transform:uppercase;letter-spacing:.5px}}.out .v{{font-size:30px;font-weight:500}}.out .d{{font-size:14px;color:{MUTED}}}
</style></head><body>
<div class="bar"><div style="background:{BLUE}"></div><div style="background:{RED}"></div><div style="background:{YELLOW}"></div><div style="background:{GREEN}"></div></div>
<main>
<h1>AI CapEx Watch</h1>
<p class="sub">Automated earnings flash and forecast tracker for Alphabet depreciation and hyperscaler CapEx. Data through {last["quarter"][:4]} Q{last["quarter"][5]} · refreshed {today} · independent case study on public SEC filings, not affiliated with Alphabet.</p>
<div class="tiles">
<div class="tile"><div class="k">Latest quarter vs forecast</div><div class="v">{float(last["error"]):+.1%}</div><div class="d">{last["quarter"][:4]} Q{last["quarter"][5]}: forecast ${float(last["forecast_musd"]) / 1000:.2f}B, reported ${float(last["actual_musd"]) / 1000:.2f}B</div></div>
<div class="tile" style="border-top-color:{GREEN}"><div class="k">Forecast error, {card["quarters_scored"]} quarters</div><div class="v">{card["mae_model"]:.1%}</div><div class="d">mean absolute error, one quarter ahead; no-change forecast {card["mae_no_change"]:.1%}, momentum {card["mae_momentum"]:.1%}</div></div>
<div class="tile" style="border-top-color:{YELLOW}"><div class="k">Next: {card["live_quarter"][:4]} Q{card["live_quarter"][5]} depreciation</div><div class="v">${card["live_forecast_musd"] / 1000:.1f}B</div><div class="d">live forecast; alert band ${card["live_low_musd"] / 1000:.1f}B to ${card["live_high_musd"] / 1000:.1f}B</div></div>
<div class="tile" style="border-top-color:{RED}"><div class="k">2027E depreciation</div><div class="v">${f["dep_2027E"] / 1000:.0f}B</div><div class="d">{f["growth_2027"]:+.0%} vs 2026E; {f["locked_share_2027"]:.0%} locked in by assets already bought</div></div>
</div>
<section><h2>The model beat a no-change forecast in {sum(abs(float(r["error"])) < abs(float(r["no_change_error"])) for r in hist)} of {len(hist)} quarters</h2>
<p class="note">Alphabet quarterly depreciation, $B. Each forecast uses only data reported before that quarter.</p>
{forecast_chart(log)}
<table><tr><th>Quarter</th><th>Data through</th><th class="n">Forecast $B</th><th class="n">Reported $B</th><th class="n">Model error</th><th class="n">No-change error</th><th class="n">Momentum error</th><th>Status</th></tr>{score_rows}</table>
<p class="note">Rows are a walk-forward backtest run today, not forecasts published at the time. Live forecasts are logged from {card["live_quarter"][:4]} Q{card["live_quarter"][5]} on. Bias over the period: {card["bias_model"]:+.1%}.</p></section>
<section><h2>Try it: what does 2027 look like under your assumptions?</h2>
<p class="note">Move the sliders. The margin and the cost guardrail recalculate from the model's 2027E depreciation.</p>
<div class="sim">
<div class="ctl">
<label>2027 CapEx budget<div class="seg" id="capex"><button data-k="low">$250B</button><button data-k="base" class="on">$300B</button><button data-k="high">$350B</button></div></label>
<label>2027 revenue growth: <b id="gv"></b><input type="range" id="g" min="5" max="35" step="1" value="19"></label>
<label>Growth in costs other than depreciation: <b id="cv"></b><input type="range" id="c" min="5" max="30" step="0.5" value="18.9"></label>
</div>
<div class="out">
<div><div class="k">2027E operating margin</div><div class="v" id="om"></div><div class="d" id="omd"></div></div>
<div><div class="k">Max cost growth to hold 2026E margin</div><div class="v" id="gr"></div><div class="d" id="grd"></div></div>
<div><div class="k">2027E depreciation</div><div class="v" id="dp"></div><div class="d" id="dpd"></div></div>
</div></div></section>
<section><h2>Replay any quarter's earnings flash</h2>
<p class="note">Pick a quarter to see how the forecast made one quarter earlier compared with what Alphabet reported.</p>
<div class="seg" id="qs"></div><p id="qt" style="font-size:18px;margin:16px 0 0"></p></section>
<section><h2>Five hyperscalers now spend about ${sum(float(p["capex_ttm_musd"]) for p in peers if p["quarter_label"] == plabel) / 1000:,.0f}B a year on CapEx</h2>
<p class="note">Trailing 12-month CapEx, $B. Microsoft and Oracle fiscal quarters mapped to the calendar quarter they mostly fall in.</p>
{pchart}
<table><tr><th>Company, {plabel[:4]} Q{plabel[5]}</th><th class="n">CapEx $B</th><th class="n">Year over year</th><th class="n">Trailing 12 months $B</th></tr>{peer_rows}</table></section>
<section><h2>Data checks: {n_pass} passed, {n_fail} failed</h2>
<p class="note">Every refresh re-derives quarters from year-to-date SEC facts and ties them to reported 3-month figures and 10-Q control totals. The refresh stops if any check fails.</p></section>
<footer>Pipeline: SEC XBRL API, SQL (BigQuery dialect), Python vintage depreciation model, GitHub Actions schedule. E = estimate.</footer>
</main>
<script>
const S = {sim};
let k = 'base';
const $ = id => document.getElementById(id), pc = (x, d = 1) => (x * 100).toFixed(d) + '%';
function calc() {{
  const g = +$('g').value / 100, c = +$('c').value / 100, dep = S.dep[k], rev = S.rev26 * (1 + g);
  const m = (rev - S.cost26 * (1 + c) - dep) / rev, guard = (rev * (1 - S.m26) - dep) / S.cost26 - 1;
  $('gv').textContent = pc(g, 0); $('cv').textContent = pc(c);
  $('om').textContent = pc(m); $('om').style.color = m >= S.m26 - 0.0005 ? '#188038' : '#D93025';
  $('omd').textContent = (m >= S.m26 - 0.0005 ? 'holds' : 'falls ' + ((S.m26 - m) * 100).toFixed(1) + ' points below') + ' the 2026E margin of ' + pc(S.m26);
  $('gr').textContent = pc(guard); $('grd').textContent = 'you set ' + pc(c) + '; 2026E pace is ' + pc(S.pace);
  $('dp').textContent = '$' + (dep / 1000).toFixed(1) + 'B'; $('dpd').textContent = pc(dep / rev) + ' of revenue, at a $' + S.capex[k] / 1000 + 'B CapEx budget';
}}
document.querySelectorAll('#capex button').forEach(b => b.onclick = () => {{ k = b.dataset.k; document.querySelectorAll('#capex button').forEach(x => x.classList.toggle('on', x === b)); calc(); }});
$('g').oninput = calc; $('c').oninput = calc; calc();
const qs = Object.keys(S.flash);
function show(q) {{
  const f = S.flash[q], side = f.a > f.f ? 'above' : 'below';
  document.querySelectorAll('#qs button').forEach(x => x.classList.toggle('on', x.dataset.q === q));
  $('qt').innerHTML = '<b>' + q.slice(0, 4) + ' Q' + q[5] + ':</b> depreciation came in at $' + (f.a / 1000).toFixed(2) + 'B, ' + Math.abs(f.e * 100).toFixed(1) + '% ' + side +
    ' the $' + (f.f / 1000).toFixed(2) + 'B forecast made with data through ' + f.t.slice(0, 4) + ' Q' + f.t[5] + '. A no-change forecast would have missed by ' + Math.abs(f.n * 100).toFixed(1) + '%.';
}}
qs.forEach(q => {{ const b = document.createElement('button'); b.textContent = q.slice(0, 4) + ' Q' + q[5]; b.dataset.q = q; b.onclick = () => show(q); $('qs').appendChild(b); }});
show(qs[qs.length - 1]);
</script></body></html>'''
    SITE.mkdir(exist_ok=True)
    (SITE / 'index.html').write_text(page)
    print('wrote site/index.html', len(page) // 1024, 'KB')


if __name__ == '__main__':
    main()
