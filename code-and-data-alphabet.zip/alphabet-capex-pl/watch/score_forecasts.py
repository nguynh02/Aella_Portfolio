"""
Forecast scorecard: walk-forward, one quarter ahead.

For each quarter Q from Q1 2025 on, the model is refit using only depreciation data reported BEFORE Q,
forecasts Q, and is scored against what Alphabet later reported. Two naive forecasts are scored the same way,
so the model has something to beat:
  no_change : next quarter = last reported quarter
  momentum  : next quarter = last quarter + last quarter-over-quarter change

Also writes the live forecast for the next unreported quarter.
Outputs: model/outputs/forecast_log.csv, model/outputs/scorecard.json
Run: python3 watch/score_forecasts.py   (about 1 minute)

Honest limits: the historical rows are a simulation run today, not forecasts published at the time.
CapEx accruals for a year are spread across its quarters, a small use of later data.
"""
import csv
import datetime
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'model'))
import depreciation_model as dm  # noqa: E402

OUT = ROOT / 'model' / 'outputs'
PUBLISHED = ROOT / 'watch' / 'published_forecasts.csv'   # frozen once written; never recomputed
FIRST_SCORED = (2025, 1)
BAND = 0.05     # alert when a quarter lands more than 5% from forecast


def prev_q(k):
    y, q = k
    return (y, q - 1) if q > 1 else (y - 1, 4)


def next_q(k):
    y, q = k
    return (y, q + 1) if q < 4 else (y + 1, 1)


def label(k):
    return f'{k[0]}Q{k[1]}'


def main():
    inp = dm.load_inputs()
    tg = dm.targets(inp)
    dep_q = tg[0]
    add = dm.build_additions(inp)
    scored = [k for k in sorted(dep_q) if FIRST_SCORED <= k <= dm.LAST_ACTUAL]
    rows = []
    for k in scored:
        origin = prev_q(k)
        _, p = dm.ranked_fits(add, tg, upto=origin)[0]          # only data through the prior quarter
        model = float(dm.run(p, add)['dep'][dm.IDX[k]])
        last, before = dep_q[origin], dep_q[prev_q(origin)]
        actual = dep_q[k]
        rows.append(dict(quarter=label(k), data_through=label(origin), kind='walk-forward backtest',
                         forecast_musd=round(model, 1), actual_musd=actual, error=model / actual - 1,
                         no_change_musd=last, no_change_error=last / actual - 1,
                         momentum_musd=2 * last - before, momentum_error=(2 * last - before) / actual - 1,
                         in_band=abs(model / actual - 1) <= BAND))
        print(f"{label(k)}: forecast {model:8,.0f}  actual {actual:8,.0f}  error {model / actual - 1:+.1%}")

    # live forecast for the next unreported quarter: full fit, 2026 mix anchored to the CFO disclosure
    nxt = next_q(dm.LAST_ACTUAL)
    _, p_live = dm.ranked_fits(add, tg, upto=dm.LAST_ACTUAL, e4=dm.E4_DISCLOSED)[0]
    live = float(dm.run(p_live, add)['dep'][dm.IDX[nxt]])
    pub = list(csv.DictReader(open(PUBLISHED))) if PUBLISHED.exists() else []
    if label(nxt) not in {r['quarter'] for r in pub}:
        pub.append(dict(quarter=label(nxt), forecast_musd=round(live, 1), data_through=label(dm.LAST_ACTUAL),
                        published_on=datetime.date.today().isoformat()))
        with open(PUBLISHED, 'w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=list(pub[0]))
            w.writeheader()
            w.writerows(pub)
    live = float(next(r for r in pub if r['quarter'] == label(nxt))['forecast_musd'])   # the frozen number
    for r in pub:     # published forecasts whose quarter has since been reported get scored as published
        k = (int(r['quarter'][:4]), int(r['quarter'][5]))
        if k in dep_q and k > dm.LAST_ACTUAL:
            fc, actual, o = float(r['forecast_musd']), dep_q[k], prev_q(k)
            rows.append(dict(quarter=r['quarter'], data_through=r['data_through'], kind=f"published {r['published_on']}",
                             forecast_musd=fc, actual_musd=actual, error=fc / actual - 1, no_change_musd=dep_q[o],
                             no_change_error=dep_q[o] / actual - 1, momentum_musd=2 * dep_q[o] - dep_q[prev_q(o)],
                             momentum_error=(2 * dep_q[o] - dep_q[prev_q(o)]) / actual - 1, in_band=abs(fc / actual - 1) <= BAND))
    if nxt not in dep_q:
        rows.append(dict(quarter=label(nxt), data_through=label(dm.LAST_ACTUAL), kind='live forecast',
                         forecast_musd=round(live, 1), actual_musd='', error='', no_change_musd=dep_q[dm.LAST_ACTUAL],
                         no_change_error='', momentum_musd=2 * dep_q[dm.LAST_ACTUAL] - dep_q[prev_q(dm.LAST_ACTUAL)],
                         momentum_error='', in_band=''))

    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / 'forecast_log.csv', 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

    hist = [r for r in rows if r['actual_musd'] != '']
    mae = lambda key: sum(abs(r[key]) for r in hist) / len(hist)
    card = dict(quarters_scored=len(hist), first=hist[0]['quarter'], last=hist[-1]['quarter'],
                mae_model=mae('error'), mae_no_change=mae('no_change_error'), mae_momentum=mae('momentum_error'),
                bias_model=sum(r['error'] for r in hist) / len(hist),
                worst=max(hist, key=lambda r: abs(r['error']))['quarter'],
                worst_error=max(hist, key=lambda r: abs(r['error']))['error'],
                in_band=sum(1 for r in hist if r['in_band']), band=BAND,
                live_quarter=label(nxt), live_forecast_musd=live,
                live_low_musd=live * (1 - BAND), live_high_musd=live * (1 + BAND))
    (OUT / 'scorecard.json').write_text(json.dumps(card, indent=1))
    print(f"\nscored {card['quarters_scored']} quarters: model MAE {card['mae_model']:.1%} | "
          f"no-change {card['mae_no_change']:.1%} | momentum {card['mae_momentum']:.1%} | bias {card['bias_model']:+.1%}")
    print(f"live: {card['live_quarter']} depreciation {live:,.0f} (band {card['live_low_musd']:,.0f} to {card['live_high_musd']:,.0f})")


if __name__ == '__main__':
    main()
