"""
Checks SEC EDGAR for new 10-Q / 10-K filings from the five tracked companies.
Compares the latest accession numbers with watch/state.json and prints new=true or new=false
(also written to $GITHUB_OUTPUT so the workflow can skip the refresh when nothing changed).

Usage: SEC_USER_AGENT="Your Name you@example.com" python3 watch/check_new_filings.py [--save]
"""
import json
import os
import pathlib
import sys
import time
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parents[1]
STATE = ROOT / 'watch' / 'state.json'
COMPANIES = {1652044: 'Alphabet', 789019: 'Microsoft', 1018724: 'Amazon', 1326801: 'Meta', 1341439: 'Oracle'}
URL = 'https://data.sec.gov/submissions/CIK{cik:010d}.json'


def fetch(cik, user_agent):
    req = urllib.request.Request(URL.format(cik=cik), headers={'User-Agent': user_agent, 'Accept': 'application/json'})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def latest_report(doc):
    """Newest 10-Q or 10-K in the 'recent' block (EDGAR lists newest first)."""
    r = doc['filings']['recent']
    for form, acc, date in zip(r['form'], r['accessionNumber'], r['filingDate']):
        if form in ('10-Q', '10-K'):
            return {'form': form, 'accession': acc, 'filed': date}
    return None


def main():
    ua = os.environ.get('SEC_USER_AGENT', '').strip()
    if '@' not in ua:
        sys.exit('Set SEC_USER_AGENT to "Your Name your.email@example.com" (SEC fair-access policy).')
    old = json.loads(STATE.read_text()) if STATE.exists() else {}
    new, changed = {}, []
    for cik, name in COMPANIES.items():
        rep = latest_report(fetch(cik, ua))
        new[name] = rep
        if rep and rep['accession'] != (old.get(name) or {}).get('accession'):
            changed.append(f"{name} {rep['form']} filed {rep['filed']}")
        time.sleep(0.25)
    flag = 'true' if changed else 'false'
    print(f'new={flag}')
    for c in changed:
        print('  new filing:', c)
    if os.environ.get('GITHUB_OUTPUT'):
        with open(os.environ['GITHUB_OUTPUT'], 'a') as fh:
            fh.write(f'new={flag}\nsummary={"; ".join(changed)}\n')
    if '--save' in sys.argv:
        STATE.write_text(json.dumps(new, indent=1) + '\n')


if __name__ == '__main__':
    main()
