#!/usr/bin/env bash
# One command to refresh everything: SQL pipeline and tie-outs, model, scorecard, flashes, dashboard.
# Stops at the first failure (a failed tie-out check exits non-zero).
set -euo pipefail
cd "$(dirname "$0")/.."
python3 pipeline/run_local_duckdb.py
python3 model/depreciation_model.py > model/outputs/run_log.txt
python3 watch/score_forecasts.py
python3 watch/make_flash.py
python3 watch/build_site.py
python3 tests/test_model.py
