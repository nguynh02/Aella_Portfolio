# CFO Memo: Alphabet 2027 Depreciation and Margin Plan

Nhi Nguyen · November 8, 2026 · Portfolio exercise on public filings only; not affiliated with Alphabet. E = estimate.

## Bottom line

Alphabet's 2027 depreciation is projected at $53B, up 69% from an estimated $31B in 2026, and 83% of it is already locked in by assets bought through Sep 30, 2026. Depreciation rises from 6.3% of revenue in 2026E to about 9.0% in 2027E (2025: 5.2%), a 2.7-point margin headwind.

To hold the 2027 operating margin at 2026E's 33.1%, costs other than depreciation can grow about 14%, versus 18.9% in 2026E. **Decision needed:** set a 14% growth guardrail on non-depreciation costs in the 2027 plan, and re-test it after the Q4 call, when 2027 CapEx guidance lands.

## Why this matters now

Alphabet spent $132.0B on property and equipment in the first nine months of 2026 but recorded only $22.0B of depreciation, a 6.0x gap (2025: 4.3x). Full-year 2026 CapEx guidance is $195-205B, more than double 2025's $91.4B.

Most of that spend has not reached the P&L yet. Construction in progress, assets bought but not yet in service, rose to $145.3B at Sep 30, 2026 from $78.6B at Dec 31, 2025. About 65% of Q3 technical infrastructure spend went to servers and network equipment, which depreciate over 6 years once live.

## 2027 forecast: $53B, mostly decided already

![83% of projected 2027 depreciation is already locked in](chart_2027_locked_in.png)

Of the $53.1B, $36.6B is depreciation on assets already in service and $7.3B is construction in progress going live; only $9.3B depends on spending from Q4 2026 on. So a $250B or $350B 2027 CapEx budget moves 2027 depreciation by under $1B, but 2028 by $5B.

The model was tested before use: fit only on data through 2024, it forecast the next seven quarters with a 2.8% mean absolute error (FY2025 within 1.3%). If 2027 misses by as much as the worst backtest quarter, 2027E lands at $50-55B.

## Margin: other costs must slow to about 14%

If 2027 revenue grows 19% and other costs keep their 2026E pace of +18.9%, the operating margin falls from 33.1% to 30.5%. Holding 33.1% caps growth in costs other than depreciation at 13.7%. Each extra point of revenue growth allows about 1.1 points more cost growth.

| 2027 revenue growth | Depreciation, % of revenue | Max cost growth to hold 33.1% | Margin if costs grow 18.9% |
| --- | --- | --- | --- |
| +15% | 9.3% | +9.3% | 28.0% |
| +19% (base) | 9.0% | +13.7% | 30.5% |
| +23% | 8.7% | +18.2% | 32.7% |

2026E is 9M actual plus a Q4 with revenue +22% and other costs +20% year over year, in line with Q3 (+24.7% and +20.0%). 2026E revenue is $496B and operating income $164B.

## Risks and triggers

The biggest swing factor is accounting, not spending. A move from 6-year to 5-year server and network lives in January 2027 would add about $13.7B to 2027 depreciation, another 2.3 points of margin. Amazon made that change for a subset of servers in January 2025, citing the pace of AI technology ([Hudson Labs](https://www.hudson-labs.com/research/amazon-server-depreciation-amzn)).

| Risk | 2027E depreciation | 2028E depreciation |
| --- | --- | --- |
| 2027 CapEx $250B / $300B / $350B | $52.3B / $53.1B / $54.0B | $79.6B / $84.6B / $89.6B |
| Server and network life cut to 5 years | +$13.7B | +$14.6B |
| Server share of 2026+ spend 60% / 70% (base 65%) | $51.9B / $54.4B | not run |

Re-test the guardrail when any of these trips:

1. Q4 2026 depreciation lands outside $9.0B to $9.9B (model: $9.4B, plus or minus the 5% backtest error band).
2. The Q4 call guides 2027 CapEx outside $250B to $350B, or changes useful lives.
3. 2027 revenue growth runs below 15%; the guardrail then tightens to about 9%.

## Method, data and sources

- **Data:** 269 SEC XBRL facts (CapEx, depreciation, revenue, operating income; 2007 to Q3 2026) from the SEC API. A SQL pipeline (BigQuery dialect, tested on DuckDB) keeps the latest filing per period, turns year-to-date facts into quarters and runs 5 tie-out checks, including 9M 2026 control totals against the 10-Q.
- **Model:** quarterly vintage engine in Python, mirrored in Excel. Spend splits into servers and network (6-year life), buildings and other assets; assets wait in construction in progress and go into service at fitted rates; the 2021 and 2023 useful-life changes apply prospectively.
- **Assumptions:** 2026 CapEx $200B (guidance midpoint); 2027 base $300B (+50%), near public analyst views of $300B+ such as Yorkville's $315B ([Webull](https://www.webull.com/news/15832742687962112)); servers and network take 65% of 2026+ spend (CFO, Q3 2026 call); 2028 CapEx +10%.

Sources: [Alphabet 10-Q, Q3 2026](https://www.sec.gov/Archives/edgar/data/1652044/000165204426000084/goog-20260930.htm) · [Alphabet 10-K, FY2025](https://www.sec.gov/Archives/edgar/data/1652044/000165204426000018/goog-20251231.htm) · [Q3 2026 earnings call transcript](https://s206.q4cdn.com/479360582/files/doc_events/2026/Oct/28/2026_Q3_Earnings_Transcript.pdf) · [SEC XBRL API, depreciation](https://data.sec.gov/api/xbrl/companyconcept/CIK0001652044/us-gaap/Depreciation.json) · [SEC XBRL API, CapEx](https://data.sec.gov/api/xbrl/companyconcept/CIK0001652044/us-gaap/PaymentsToAcquirePropertyPlantAndEquipment.json)
