INDEGO BIKE SHARE GROWTH ANALYSIS
Aella Nguyen
SUPPORTING ANALYSIS

Data: Indego public trip datasets, 2025 Q1-Q3 and 2026 Q1-Q3
Public source: https://www.rideindego.com/about/data/
Station metadata: indego-stations-2026-10-15.csv (public Indego station table)

MAIN OUTPUTS
01_quarter_growth.csv: 2025/2026 Q1-Q3 growth by trips and duration minutes
02_ytd_executive_summary.csv: Jan-Sep year-over-year totals
03_station_comparison.csv: counts and ride-minutes by trip start station and launch cohort
04_bike_type.csv: trip and duration totals for standard/electric bikes

REPRODUCIBILITY
indego_growth_analysis.py: plain Python 3 code used for the aggregation (standard library only).
Download the six source trip CSVs and the station CSV from Indego's website, put them in one
folder with the .py file, then run:
    python indego_growth_analysis.py
or, from Jupyter:
    %run indego_growth_analysis.py

METHOD AND LIMITATIONS
- Ride-minutes are used as a duration-based revenue proxy (not measured revenue).
- Year-over-year comparisons compare the same months, January through September.
- Durations >0 and <=1,440 minutes are included. Trips >180 minutes are flagged
  for further investigation; they are not removed automatically.
- Station ride-minutes are attributed to each trip's start station; they are
  NOT utilization per physical bike/dock or measures of investment ROI.
- Mature network refers to stations with go-live dates before Jan 1, 2025.
- Go-live cohorts are indicative; the 2025 cohort has non-uniform exposure in
  the two comparison periods.
- Source trip IDs were not globally deduplicated.
- The slides discuss evidence and a proposed reversible pilot, not a
  proven profitability forecast.
