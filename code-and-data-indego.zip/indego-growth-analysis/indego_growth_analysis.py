"""Indego bike-share growth analysis (Aella Nguyen): read 6 large quarterly CSV files automatically.

Place this file in the same folder as:
  indego-trips-2025-q1.csv ... indego-trips-2025-q3.csv
  indego-trips-2026-q1.csv ... indego-trips-2026-q3.csv
  indego-stations-2026-10-15.csv

Run in Jupyter: %run indego_growth_analysis.py

Requires only Python 3 (no pandas / no extra installation).
Outputs small Excel-compatible CSV files in a new 'indego_results' folder.
"""
from __future__ import annotations

import csv
from collections import defaultdict
from datetime import datetime, date
from pathlib import Path

HOME = Path(__file__).resolve().parent
OUT = HOME / "indego_results"
OUT.mkdir(exist_ok=True)
YEARS = (2025, 2026)
QUARTERS = (1, 2, 3)
MAX_VALID_DURATION = 1440  # Data documentation states trips can last up to 24 hours.


def blank_summary():
    return {"trips": 0, "valid_trips": 0, "ride_minutes": 0,
            "long_over_180": 0, "invalid_duration": 0,
            "electric_trips": 0, "standard_trips": 0,
            "wrong_period": 0, "missing_station": 0,
            "missing_trip_id": 0, "unreadable_date": 0}


def growth(current, prior):
    """Percentage change, blank when no valid baseline."""
    return round((current / prior - 1) * 100, 2) if prior else ""


def mean(total, count):
    return round(total / count, 2) if count else ""


def export(name, columns, records):
    path = OUT / name
    # utf-8-sig ensures names with accents open correctly in Windows Excel.
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    print("   ->", path.name)


def get_station_info():
    matches = sorted(HOME.glob("indego-stations-*.csv"), reverse=True)
    stations = {}
    if not matches:
        print("WARNING: station file not found; station names/launch dates unavailable.")
        return stations
    with matches[0].open("r", newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            station_id = (row.get("Station_ID") or "").strip()
            if not station_id:
                continue  # Some published station files have blank trailing lines.
            date_str = (row.get("Day of Go_live_date") or "").strip()
            go_live = None
            if date_str:
                try:
                    go_live = datetime.strptime(date_str, "%m/%d/%Y").date()
                except ValueError:
                    pass
            stations[station_id] = {
                "name": (row.get("Station_Name") or "").strip(),
                "go_live": go_live,
                "status_2026_10": (row.get("Status") or "").strip(),
            }
    print(f"Station metadata: {len(stations):,} nonblank station IDs.")
    return stations


stations = get_station_info()
quarters = {}   # (year, quarter) -> summary
by_station = defaultdict(lambda: {2025: {"trips": 0, "minutes": 0},
                                  2026: {"trips": 0, "minutes": 0}})
by_bike = defaultdict(lambda: {"trips": 0, "minutes": 0})  # (year, bike type)
missing = []
# File matching ignores uppercase/lowercase (e.g. 2026-Q3 vs 2026-q3).
available_csv = {p.name.casefold(): p for p in HOME.iterdir()
                 if p.is_file() and p.suffix.casefold() == ".csv"}

for year in YEARS:
    for quarter in QUARTERS:
        expected_name = f"indego-trips-{year}-q{quarter}.csv"
        source = available_csv.get(expected_name.casefold())
        if source is None:
            missing.append(expected_name)
            continue
        print(f"Reading {source.name} ({source.stat().st_size / 1024**2:.1f} MB) ...", flush=True)
        stat = blank_summary()
        with source.open("r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            required = {"trip_id", "duration", "start_time", "start_station", "bike_type"}
            absent = required - set(reader.fieldnames or [])
            if absent:
                raise ValueError(f"{source.name} is missing columns: {sorted(absent)}")
            for r in reader:  # STREAM rows; no need to load files into RAM.
                stat["trips"] += 1
                if not (r.get("trip_id") or "").strip():
                    stat["missing_trip_id"] += 1

                start_time = (r.get("start_time") or "").strip()
                try:
                    # Indego uses M/D/YYYY in older releases and YYYY-MM-DD in 2026 Q3.
                    daypart = start_time.split()[0].split("T")[0]
                    if "-" in daypart:
                        y, m, d = (int(v) for v in daypart.split("-"))
                    else:
                        m, d, y = (int(v) for v in daypart.split("/"))
                    date(y, m, d)  # Also rejects impossible dates (e.g., month 13).
                    actual_quarter = (m - 1) // 3 + 1
                    if y != year or actual_quarter != quarter:
                        stat["wrong_period"] += 1
                except (ValueError, IndexError):
                    stat["unreadable_date"] += 1

                station = (r.get("start_station") or "").strip()
                if not station:
                    stat["missing_station"] += 1
                bike = (r.get("bike_type") or "Unknown").strip().lower()
                if bike == "electric":
                    stat["electric_trips"] += 1
                elif bike == "standard":
                    stat["standard_trips"] += 1

                # A trip can still count toward trips even when its duration is unusable.
                if station:
                    by_station[station][year]["trips"] += 1
                by_bike[(year, bike)]["trips"] += 1
                try:
                    duration = float((r.get("duration") or "").strip())
                except ValueError:
                    duration = -1
                if not 0 < duration <= MAX_VALID_DURATION:
                    stat["invalid_duration"] += 1
                    continue
                stat["valid_trips"] += 1
                stat["ride_minutes"] += duration
                if duration > 180:
                    stat["long_over_180"] += 1
                if station:
                    by_station[station][year]["minutes"] += duration
                by_bike[(year, bike)]["minutes"] += duration
        quarters[(year, quarter)] = stat
        print(f"  {stat['trips']:,} trips; {stat['ride_minutes']:,.0f} ride-minutes")

if missing:
    print("\nNOTE: Missing files (this run will be INCOMPLETE):")
    for name in missing:
        print("  ", name)

quarter_rows = []
for year in YEARS:
    for quarter in QUARTERS:
        if (year, quarter) not in quarters:
            continue
        s = quarters[(year, quarter)]
        last = quarters.get((year - 1, quarter))
        quarter_rows.append({
            "year": year, "quarter": f"Q{quarter}",
            "trips": s["trips"], "trip_growth_yoy_pct": growth(s["trips"], last["trips"]) if last else "",
            "total_ride_minutes": round(s["ride_minutes"], 2),
            "ride_minutes_growth_yoy_pct": growth(s["ride_minutes"], last["ride_minutes"]) if last else "",
            "avg_minutes_per_valid_trip": mean(s["ride_minutes"], s["valid_trips"]),
            "electric_share_trips_pct": round(100*s["electric_trips"]/s["trips"], 2) if s["trips"] else "",
            "valid_duration_trips": s["valid_trips"],
            "bad_duration_trips": s["invalid_duration"],
            "trips_over_180_minutes": s["long_over_180"],
        })
export("01_quarter_growth.csv", list(quarter_rows[0].keys()) if quarter_rows else
       ["year", "quarter", "trips"], quarter_rows)

def sum_year(year, metric):
    return sum(quarters.get((year, q), {}).get(metric, 0) for q in QUARTERS)

has_full_window = all((y, q) in quarters for y in YEARS for q in QUARTERS)
if has_full_window:
    base = sum_year(2025, "trips")
    latest = sum_year(2026, "trips")
    base_min = sum_year(2025, "ride_minutes")
    latest_min = sum_year(2026, "ride_minutes")
    summary_ytd = [{
        "comparison": "Jan-Sep 2026 vs Jan-Sep 2025",
        "trips_2025": base, "trips_2026": latest,
        "trips_growth_pct": growth(latest, base),
        "ride_minutes_2025": round(base_min, 2),
        "ride_minutes_2026": round(latest_min, 2),
        "ride_minutes_growth_pct": growth(latest_min, base_min),
        "avg_duration_2025": mean(base_min, sum_year(2025,"valid_trips")),
        "avg_duration_2026": mean(latest_min, sum_year(2026,"valid_trips")),
        "electric_share_2025_pct": round(100*sum_year(2025,"electric_trips")/base, 2) if base else "",
        "electric_share_2026_pct": round(100*sum_year(2026,"electric_trips")/latest, 2) if latest else "",
    }]
    export("02_ytd_executive_summary.csv", list(summary_ytd[0].keys()), summary_ytd)
else:
    print("Skipping YTD executive comparison: all 6 quarterly files are required.")

station_rows = []
for st, yearly in by_station.items():
    meta = stations.get(st, {})
    go_live = meta.get("go_live")
    if st == "3000":
        cohort = "Virtual station (exclude from physical-station ranking)"
    elif go_live is None:
        cohort = "Unknown launch date"
    elif go_live <= date(2025, 1, 1):
        cohort = "Opened before 2025 (mature network)"
    elif go_live.year == 2025:
        cohort = "Opened in 2025"
    elif go_live.year >= 2026:
        cohort = "Opened in 2026 or later"
    else:
        cohort = "Unknown launch date"
    a, b = yearly[2025], yearly[2026]
    station_rows.append({
        "station_id": st,
        "station_name": meta.get("name", "Unknown station"),
        "station_go_live": go_live.isoformat() if go_live else "",
        "station_status_in_metadata": meta.get("status_2026_10", "Unknown"),
        "station_cohort": cohort,
        "trips_2025_jan_sep": a["trips"],
        "trips_2026_jan_sep": b["trips"],
        "trips_yoy_pct": growth(b["trips"], a["trips"]) if has_full_window else "",
        "minutes_2025_jan_sep": round(a["minutes"], 2),
        "minutes_2026_jan_sep": round(b["minutes"], 2),
        "minutes_yoy_pct": growth(b["minutes"], a["minutes"]) if has_full_window else "",
    })
station_rows.sort(key=lambda r: r["minutes_2026_jan_sep"], reverse=True)
export("03_station_comparison.csv", list(station_rows[0].keys()) if station_rows else
       ["station_id", "station_name"], station_rows)

bike_rows = []
for y, t in sorted(by_bike):
    s = by_bike[(y,t)]
    prev = by_bike.get((y-1,t))
    bike_rows.append({"year":y,"bike_type":t,"trips":s["trips"],
      "ride_minutes":round(s["minutes"],2),
      "trip_growth_yoy_pct":growth(s["trips"], prev["trips"]) if prev and has_full_window else "",
      "minutes_growth_yoy_pct":growth(s["minutes"],prev["minutes"]) if prev and has_full_window else ""})
export("04_bike_type.csv", list(bike_rows[0].keys()) if bike_rows else
       ["year", "bike_type", "trips", "ride_minutes"], bike_rows)

qa_rows = []
for (year,q),s in sorted(quarters.items()):
    qa_rows.append({"period":f"{year} Q{q}", **s})
export("05_data_quality.csv", list(qa_rows[0].keys()) if qa_rows else ["period"], qa_rows)

lines = [
    "INDEGO BIKE SHARE GROWTH ANALYSIS - QUICK GUIDE TO THE OUTPUT",
    "Source: Indego public quarterly trip files; read from the same folder as this script.",
    "Coverage: January-September of 2025 and 2026, if all 6 quarter files are present.",
    "",
    "IMPORTANT: This is a PROFIT-MOTIVATED business hypothetical, not actual Indego financials.",
    "Total ride-minutes is a DURATION-BASED REVENUE PROXY (an assumption of this analysis).",
    "It is NOT measured revenue, profit, bike utilization, fleet capacity or ROI.",
    "",
    "FILES:",
    "01_quarter_growth.csv = 6 quarterly rows, YoY growth, average duration, bike mix.",
    "02_ytd_executive_summary.csv = Jan-Sep YoY comparison when all 6 files exist.",
    "03_station_comparison.csv = stations ranked by 2026 trip-origin ride-minutes.",
    "04_bike_type.csv = electric/standard trips and minutes by year.",
    "05_data_quality.csv = count of unusually long trips, invalid durations and mismatches.",
    "",
    "STATION NOTE: Station analysis assigns ride-minutes to trip START station; this is a demand",
    "proxy, not capacity-adjusted utilization. 'Mature' stations were launched before Jan 2025.",
    "Do not compare station % changes when baseline is close to zero or a station just opened.",
    "Latest station active/inactive status is not proof of its status in a past quarter.",
    "",
    "DATA CHECK: Valid ride-minutes are duration > 0 and <= 1440 min. Bad durations",
    "still count toward raw trip total, but are excluded from duration calculations.",
    "Long trips >180 min are flagged, not removed. Try sensitivity tests if there are many.",
    "Trip IDs were NOT deduplicated: verify if duplicates are suspected.",
    "Trip counts grouped by source filename; wrong-period dates flagged in quality sheet.",
    "",
    "SLIDE IDEA: 1) What happened (trip growth vs ride-minute growth, quarterly and YTD).",
    "            2) Why it matters + targeted pilot recommendation based on station evidence.",
]
if has_full_window:
    s = summary_ytd[0]
    lines += ["", "JAN-SEP RESULTS:",
              f"Trips: {s['trips_2025']:,} (2025) -> {s['trips_2026']:,} (2026); YoY {s['trips_growth_pct']}%",
              f"Minutes: {s['ride_minutes_2025']:,.0f} (2025) -> {s['ride_minutes_2026']:,.0f} (2026); YoY {s['ride_minutes_growth_pct']}%",
              f"Average duration: {s['avg_duration_2025']} min -> {s['avg_duration_2026']} min"]
else:
    lines += ["", "INCOMPLETE: Year-on-year YTD metrics are withheld until all six files exist.",
              "Missing: " + ", ".join(missing)]
(OUT / "00_READ_ME_FIRST.txt").write_text("\n".join(lines)+"\n", encoding="utf-8")
print("\nDONE. Open this folder:", OUT)
print("Start with 00_READ_ME_FIRST.txt and 02_ytd_executive_summary.csv (when available).")
